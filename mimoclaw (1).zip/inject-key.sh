#!/bin/bash
# MiMoClaw Key Inject
# 
# 用途: 外部 cron/云函数/手动调用，将新 key 推送到 MiMoClaw
#
# 用法:
#   ./inject-key.sh "你的新API_KEY"
#   MIMO_API_KEY="新key" ./inject-key.sh
#   # crontab 示例: 每55分钟刷新一次
#   */55 * * * * /path/to/inject-key.sh >> /tmp/mimo-key.log 2>&1

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
KEY_FILE="$SCRIPT_DIR/.api_keys.json"
MIMOCLAW_URL="${MIMOCLAW_URL:-http://127.0.0.1:3000}"

# 获取 key（参数优先，其次环境变量）
KEY="${1:-$MIMO_API_KEY}"

if [ -z "$KEY" ]; then
  echo "[$(date)] ❌ 未提供 key"
  echo "用法: $0 <新API_KEY>"
  echo "  或: MIMO_API_KEY=新key $0"
  exit 1
fi

# 显示 key 前后几位
MASKED="${KEY:0:8}...${KEY: -4}"
echo "[$(date)] 🔄 注入 key: $MASKED"

# 写入 key 文件
if [ -f "$KEY_FILE" ]; then
  # 用 node 更新 JSON（兼容性好）
  node -e "
    const fs = require('fs');
    const keys = JSON.parse(fs.readFileSync('$KEY_FILE', 'utf-8'));
    keys.mimo = '$KEY';
    fs.writeFileSync('$KEY_FILE', JSON.stringify(keys, null, 2));
  "
else
  echo "{\"mimo\":\"$KEY\"}" > "$KEY_FILE"
fi

# 通知 MiMoClaw 服务
RESULT=$(curl -s -X POST "$MIMOCLAW_URL/api/keys" \
  -H "Content-Type: application/json" \
  -d "{\"mimo\":\"$KEY\"}" \
  --connect-timeout 3 --max-time 5 2>/dev/null)

if [ $? -eq 0 ]; then
  echo "[$(date)] ✅ 已通知 MiMoClaw: $RESULT"
else
  echo "[$(date)] ⚠️ MiMoClaw 未运行，key 已写入文件，启动后自动加载"
fi
