#!/usr/bin/env node
/**
 * MiMoClaw Key Refresher - 多来源 Key 同步
 * 
 * 支持的 Key 来源（按优先级）：
 * 1. Shell 环境变量 $MIMO_API_KEY（如果外部进程更新了系统级环境变量）
 * 2. 自定义 key 文件 ~/.openclaw/mimo_key.txt（外部脚本/cron 写入）
 * 3. /proc/<gateway>/environ（OpenClaw 进程启动时的 key）
 * 4. .api_keys.json 中的旧值
 * 
 * 用法:
 *   node key-refresher.js          # 前台运行
 *   node key-refresher.js &        # 后台运行
 *   node key-refresher.js --once   # 只刷新一次
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const KEY_FILE = path.join(__dirname, '.api_keys.json');
const CUSTOM_KEY_FILE = path.resolve(__dirname, '../../mimo_key.txt');  // ~/.openclaw/mimo_key.txt
const CHECK_INTERVAL = 60 * 1000; // 每分钟检查

// === Key Sources ===

// Source 1: Shell environment (most up-to-date if system env was updated)
function getKeyFromShell() {
  try {
    const result = execSync('bash -lc "echo -n $MIMO_API_KEY"', { encoding: 'utf-8', timeout: 5000 });
    return result.trim();
  } catch (_) {}
  return '';
}

// Source 2: Custom key file (external scripts can write here)
function getKeyFromFile() {
  try {
    if (fs.existsSync(CUSTOM_KEY_FILE)) {
      return fs.readFileSync(CUSTOM_KEY_FILE, 'utf-8').trim();
    }
  } catch (_) {}
  return '';
}

// Source 3: /proc gateway environ (may be stale if gateway wasn't restarted)
function getKeyFromProc() {
  try {
    const pids = execSync("pgrep -f 'openclaw-gatewa'", { encoding: 'utf-8', timeout: 3000 }).trim().split('\n');
    for (const pid of pids) {
      const environPath = `/proc/${pid.trim()}/environ`;
      if (!fs.existsSync(environPath)) continue;
      const environ = fs.readFileSync(environPath, 'utf-8');
      for (const v of environ.split('\0')) {
        if (v.startsWith('MIMO_API_KEY=')) return v.slice('MIMO_API_KEY='.length);
      }
    }
  } catch (_) {}
  return '';
}

// Source 4: Current env var
function getKeyFromEnv() {
  return process.env.MIMO_API_KEY || '';
}

// Combined: try all sources, return best key
function getCurrentKey() {
  const sources = [
    { name: 'Shell', fn: getKeyFromShell },
    { name: '文件', fn: getKeyFromFile },
    { name: '/proc', fn: getKeyFromProc },
    { name: 'env', fn: getKeyFromEnv },
  ];
  
  for (const s of sources) {
    const key = s.fn();
    if (key) return { key, source: s.name };
  }
  return { key: '', source: 'none' };
}

// === File operations ===

function readKeyFile() {
  try { return JSON.parse(fs.readFileSync(KEY_FILE, 'utf-8')); } catch (_) { return {}; }
}

function writeKeyFile(keys) {
  fs.writeFileSync(KEY_FILE, JSON.stringify(keys, null, 2), 'utf-8');
}

function maskKey(key) {
  if (!key) return '(空)';
  return key.slice(0, 8) + '...' + key.slice(-4);
}

// === Main logic ===

function refreshKey() {
  const { key: envKey, source } = getCurrentKey();
  if (!envKey) {
    console.log(`[Refresher] ⚠️ 所有来源均无 MIMO_API_KEY`);
    console.log(`  尝试的来源: Shell, 文件(${CUSTOM_KEY_FILE}), /proc, env`);
    return false;
  }

  const current = readKeyFile();
  if (current.mimo === envKey) return false; // unchanged

  const oldKey = current.mimo ? maskKey(current.mimo) : '(空)';
  current.mimo = envKey;
  writeKeyFile(current);
  const now = new Date().toLocaleTimeString();
  console.log(`[Refresher] ✅ Key 已更新 @ ${now} (来源: ${source})`);
  console.log(`    旧: ${oldKey}`);
  console.log(`    新: ${maskKey(envKey)}`);
  return true;
}

function notifyServer(key) {
  try {
    const http = require('http');
    const body = JSON.stringify({ mimo: key });
    const req = http.request({
      hostname: '127.0.0.1',
      port: process.env.PORT || 3000,
      path: '/api/keys',
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
    }, () => {});
    req.on('error', () => {});
    req.setTimeout(3000, () => req.destroy());
    req.write(body);
    req.end();
  } catch (_) {}
}

// === Startup ===
console.log('=== MiMoClaw Key Refresher ===');
console.log(`检查间隔: ${CHECK_INTERVAL / 1000} 秒`);
console.log(`Key 文件: ${KEY_FILE}`);
console.log(`自定义文件: ${CUSTOM_KEY_FILE}`);
console.log('');

// Show all sources
console.log('Key 来源检测:');
const sources = [
  { name: 'Shell 环境变量', fn: getKeyFromShell },
  { name: `自定义文件`, fn: getKeyFromFile },
  { name: '/proc (Gateway)', fn: getKeyFromProc },
  { name: '进程 env', fn: getKeyFromEnv },
];
sources.forEach(s => {
  const key = s.fn();
  console.log(`  ${s.name}: ${key ? '✅ ' + maskKey(key) : '❌ 未找到'}`);
});
console.log('');

// External refresh instructions
console.log('💡 如果 Key 过期，可以用以下方式手动更新:');
console.log(`   1. 写入文件: echo "新key" > ${CUSTOM_KEY_FILE}`);
console.log(`   2. curl: curl -X POST http://localhost:3000/api/keys -d '{"mimo":"新key"}'`);
console.log(`   3. 运行: node key-manager.js (打开 UI 手动输入)`);
console.log('');

// Initial refresh
const { key } = getCurrentKey();
if (refreshKey()) notifyServer(key);

// One-shot mode
if (process.argv.includes('--once')) {
  console.log('单次模式，退出');
  process.exit(0);
}

// Periodic refresh
setInterval(() => {
  const { key } = getCurrentKey();
  if (refreshKey()) notifyServer(key);
}, CHECK_INTERVAL);

console.log('后台运行中... (Ctrl+C 退出)');
