#!/usr/bin/env node
/**
 * MiMoClaw Key Manager - 独立工具
 * 
 * 启动后打开浏览器，实时显示和管理 API Key
 * 
 * 用法:
 *   node key-manager.js              # 启动 (默认端口 3001)
 *   node key-manager.js --port 8080  # 自定义端口
 * 
 * 功能:
 *   - 实时显示当前可用的 Key
 *   - 一键从环境变量刷新
 *   - 手动输入/替换 Key
 *   - 检测 Key 是否可用
 *   - 自动同步到 MiMoClaw (.api_keys.json)
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const https = require('https');
const { execSync } = require('child_process');

const PORT = parseInt(process.argv.find((_, i, a) => a[i - 1] === '--port') || '3001');
const KEY_FILE = path.join(__dirname, '.api_keys.json');
const MIMOCLAW_PORT = parseInt(process.env.PORT || '3000');

// ==================== Key Management ====================

function readKeys() {
  try {
    return JSON.parse(fs.readFileSync(KEY_FILE, 'utf-8'));
  } catch (_) {
    return {};
  }
}

function writeKeys(keys) {
  fs.writeFileSync(KEY_FILE, JSON.stringify(keys, null, 2), 'utf-8');
}

function getEnvKey() {
  return process.env.MIMO_API_KEY || '';
}

function maskKey(key) {
  if (!key) return '(空)';
  if (key.length <= 16) return key;
  return key.slice(0, 10) + '****' + key.slice(-6);
}

async function testKey(baseUrl, apiKey, model) {
  return new Promise((resolve) => {
    const body = JSON.stringify({
      model: model || 'mimo-v2-pro',
      messages: [{ role: 'user', content: '回复:ok' }],
      max_tokens: 20,
      stream: false
    });
    const url = new URL((baseUrl || 'https://api.xiaomimimo.com/v1').replace(/\/+$/, '') + '/chat/completions');
    const start = Date.now();
    const req = https.request({
      hostname: url.hostname,
      port: 443,
      path: url.pathname,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + apiKey,
        'Content-Length': Buffer.byteLength(body)
      }
    }, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        const ms = Date.now() - start;
        if (res.statusCode === 200) {
          try {
            const parsed = JSON.parse(d);
            resolve({ ok: true, status: 200, ms, reply: (parsed.choices?.[0]?.message?.content || '').slice(0, 50) });
          } catch (_) {
            resolve({ ok: true, status: 200, ms, reply: '解析成功' });
          }
        } else {
          resolve({ ok: false, status: res.statusCode, ms, error: d.slice(0, 200) });
        }
      });
    });
    req.on('error', (e) => resolve({ ok: false, error: e.message, ms: Date.now() - start }));
    req.setTimeout(10000, () => { req.destroy(); resolve({ ok: false, error: '超时', ms: 10000 }); });
    req.write(body);
    req.end();
  });
}

// ==================== HTTP Server ====================

const HTML = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>🔑 MiMoClaw Key Manager</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Microsoft YaHei',sans-serif;background:#0f0f13;color:#e4e4ef;min-height:100vh;padding:20px}
.container{max-width:700px;margin:0 auto}
h1{font-size:22px;margin-bottom:4px}
h1 span{color:#7c6aef}
.subtitle{color:#9393a8;font-size:13px;margin-bottom:24px}
.card{background:#16161d;border:1px solid #2a2a3a;border-radius:10px;padding:16px 20px;margin-bottom:16px}
.card h2{font-size:14px;font-weight:600;margin-bottom:12px;display:flex;align-items:center;gap:8px}
.key-row{display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid #2a2a3a}
.key-row:last-child{border-bottom:none}
.key-name{font-weight:600;font-size:13px}
.key-value{font-family:Consolas,monospace;font-size:12px;color:#9393a8}
.key-status{font-size:11px;padding:2px 8px;border-radius:4px;font-weight:600}
.key-status.ok{background:rgba(74,222,128,.15);color:#4ade80}
.key-status.err{background:rgba(248,113,113,.15);color:#f87171}
.key-status.unknown{background:rgba(147,147,168,.15);color:#9393a8}
.btn{padding:8px 16px;border-radius:6px;font-size:13px;cursor:pointer;border:1px solid #2a2a3a;transition:all .2s;font-family:inherit;background:#1e1e28;color:#e4e4ef}
.btn:hover{border-color:#7c6aef;color:#7c6aef}
.btn.primary{background:#7c6aef;color:white;border-color:#7c6aef}
.btn.primary:hover{background:#9d8df7}
.btn:disabled{opacity:.5;cursor:not-allowed}
.btn-group{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
.input-group{margin-bottom:12px}
.input-group label{display:block;font-size:12px;color:#9393a8;margin-bottom:4px;font-weight:600}
.input-group input{width:100%;background:#0f0f13;border:1px solid #2a2a3a;border-radius:6px;padding:8px 10px;color:#e4e4ef;font-size:13px;font-family:Consolas,monospace;outline:none}
.input-group input:focus{border-color:#7c6aef}
.log{background:#0f0f13;border:1px solid #2a2a3a;border-radius:6px;padding:10px 12px;font-size:12px;font-family:Consolas,monospace;color:#9393a8;max-height:200px;overflow-y:auto;line-height:1.6}
.log .ok{color:#4ade80}.log .err{color:#f87171}.log .info{color:#60a5fa}
.auto-refresh{display:flex;align-items:center;gap:8px;margin-top:8px;font-size:12px;color:#9393a8}
.toggle{width:34px;height:18px;background:#282836;border-radius:9px;cursor:pointer;position:relative;transition:background .2s;display:inline-block}
.toggle.on{background:#7c6aef}
.toggle::after{content:'';position:absolute;top:2px;left:2px;width:14px;height:14px;background:white;border-radius:50%;transition:transform .2s}
.toggle.on::after{transform:translateX(16px)}
</style>
</head>
<body>
<div class="container">
  <h1>🔑 <span>MiMoClaw</span> Key Manager</h1>
  <p class="subtitle">实时监控 API Key 状态，自动刷新，手动管理</p>

  <div class="card">
    <h2>📊 当前 Key 状态 <span id="last-update" style="font-size:11px;color:#5e5e72;font-weight:400;margin-left:auto"></span></h2>
    <div id="key-list">加载中...</div>
    <div class="btn-group">
      <button class="btn primary" onclick="refreshFromEnv()">🔄 从环境变量刷新</button>
      <button class="btn" onclick="testAll()">🔍 检测全部</button>
      <button class="btn" onclick="loadStatus()">🔃 重新加载</button>
    </div>
    <div class="auto-refresh">
      <span class="toggle on" id="auto-toggle" onclick="toggleAuto()"></span>
      <span>自动刷新 (每30秒)</span>
      <span id="auto-status" style="margin-left:auto;color:#4ade80">● 运行中</span>
    </div>
  </div>

  <div class="card">
    <h2>✏️ 手动设置 Key</h2>
    <div class="input-group">
      <label>Key 名称</label>
      <input id="manual-key-name" value="mimo" placeholder="mimo">
    </div>
    <div class="input-group">
      <label>Key 值</label>
      <input id="manual-key-value" placeholder="粘贴你的 API Key..." type="password">
    </div>
    <div class="btn-group">
      <button class="btn primary" onclick="setManualKey()">💾 保存 Key</button>
      <button class="btn" onclick="testManual()">🔍 测试这个 Key</button>
      <button class="btn" onclick="toggleVisibility()">👁 显示/隐藏</button>
    </div>
  </div>

  <div class="card">
    <h2>📋 操作日志</h2>
    <div class="log" id="log">等待操作...</div>
  </div>

  <div class="card">
    <h2>ℹ️ 说明</h2>
    <div style="font-size:12px;color:#9393a8;line-height:1.7">
      <p><strong>Key 刷新逻辑：</strong></p>
      <p>1. 环境变量 <code>MIMO_API_KEY</code> 每小时自动刷新</p>
      <p>2. 此工具读取环境变量并写入 <code>.api_keys.json</code></p>
      <p>3. MiMoClaw 从 <code>.api_keys.json</code> 读取最新 Key</p>
      <p>4. API 返回 401/403 时 MiMoClaw 自动重试</p>
      <br>
      <p><strong>如果自动刷新失效：</strong></p>
      <p>1. 在上面"手动设置 Key"中粘贴新 Key</p>
      <p>2. 点击"检测全部"确认可用</p>
      <p>3. MiMoClaw 会在下次请求时自动使用新 Key</p>
    </div>
  </div>
</div>

<script>
var autoRefresh = true;
var autoTimer = null;

async function api(url, opts) {
  try { return await (await fetch(url, opts)).json(); }
  catch (e) { return { error: e.message }; }
}

function log(msg, cls) {
  var el = document.getElementById('log');
  var time = new Date().toLocaleTimeString();
  el.innerHTML = '<div><span class="' + (cls || 'info') + '">[' + time + ']</span> ' + msg + '</div>' + el.innerHTML;
  if (el.children.length > 50) el.removeChild(el.lastChild);
}

async function loadStatus() {
  var data = await api('/api/status');
  if (data.error) { log('加载失败: ' + data.error, 'err'); return; }
  
  var html = '';
  (data.keys || []).forEach(function(k) {
    var statusCls = k.valid === true ? 'ok' : k.valid === false ? 'err' : 'unknown';
    var statusText = k.valid === true ? '✅ 可用' : k.valid === false ? '❌ 失效' : '❓ 未检测';
    html += '<div class="key-row">' +
      '<div><div class="key-name">' + k.name + '</div><div class="key-value">' + k.masked + '</div></div>' +
      '<span class="key-status ' + statusCls + '">' + statusText + '</span></div>';
  });
  
  if (!html) html = '<div style="color:#5e5e72;text-align:center;padding:12px">暂无 Key</div>';
  document.getElementById('key-list').innerHTML = html;
  document.getElementById('last-update').textContent = '更新于 ' + new Date().toLocaleTimeString();
}

async function refreshFromEnv() {
  log('正在从环境变量读取...', 'info');
  var data = await api('/api/refresh-env', { method: 'POST' });
  if (data.ok) {
    log('✅ 已刷新: ' + data.changes.join(', '), 'ok');
  } else {
    log('❌ ' + (data.error || '刷新失败'), 'err');
  }
  loadStatus();
}

async function testAll() {
  log('正在检测所有 Key...', 'info');
  var data = await api('/api/test-all', { method: 'POST' });
  if (data.results) {
    data.results.forEach(function(r) {
      var cls = r.ok ? 'ok' : 'err';
      log((r.ok ? '✅' : '❌') + ' ' + r.name + ': ' + (r.ok ? r.reply + ' (' + r.ms + 'ms)' : r.error), cls);
    });
  }
  loadStatus();
}

async function setManualKey() {
  var name = document.getElementById('manual-key-name').value.trim();
  var value = document.getElementById('manual-key-value').value.trim();
  if (!name || !value) { log('请填写名称和 Key 值', 'err'); return; }
  
  log('正在保存 ' + name + '...', 'info');
  var data = await api('/api/set-key', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: name, key: value })
  });
  if (data.ok) {
    log('✅ 已保存: ' + name, 'ok');
    document.getElementById('manual-key-value').value = '';
  } else {
    log('❌ ' + (data.error || '保存失败'), 'err');
  }
  loadStatus();
}

async function testManual() {
  var value = document.getElementById('manual-key-value').value.trim();
  if (!value) { log('请先输入 Key', 'err'); return; }
  
  log('正在测试...', 'info');
  var data = await api('/api/test-key', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ key: value })
  });
  if (data.ok) {
    log('✅ Key 可用: ' + data.reply + ' (' + data.ms + 'ms)', 'ok');
  } else {
    log('❌ Key 无效: ' + (data.error || 'HTTP ' + data.status), 'err');
  }
}

function toggleVisibility() {
  var inp = document.getElementById('manual-key-value');
  inp.type = inp.type === 'password' ? 'text' : 'password';
}

function toggleAuto() {
  autoRefresh = !autoRefresh;
  document.getElementById('auto-toggle').classList.toggle('on', autoRefresh);
  document.getElementById('auto-status').textContent = autoRefresh ? '● 运行中' : '○ 已暂停';
  document.getElementById('auto-status').style.color = autoRefresh ? '#4ade80' : '#5e5e72';
  if (autoRefresh) startAutoRefresh();
  else if (autoTimer) clearInterval(autoTimer);
}

function startAutoRefresh() {
  if (autoTimer) clearInterval(autoTimer);
  autoTimer = setInterval(function() {
    if (autoRefresh) loadStatus();
  }, 30000);
}

// Init
loadStatus();
startAutoRefresh();
log('Key Manager 已启动', 'info');
</script>
</body>
</html>`;

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');

  // Serve UI
  if (url.pathname === '/' || url.pathname === '/index.html') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(HTML);
    return;
  }

  // API: Get status
  if (url.pathname === '/api/status' && req.method === 'GET') {
    const keys = readKeys();
    const envKey = getEnvKey();
    const result = [];
    
    if (keys.mimo || envKey) {
      const key = keys.mimo || envKey;
      result.push({ name: 'mimo (MiMo-C/D)', masked: maskKey(key), valid: null });
    }
    Object.keys(keys).forEach(k => {
      if (k === 'mimo') return;
      result.push({ name: k, masked: maskKey(keys[k]), valid: null });
    });

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ keys: result }));
    return;
  }

  // API: Refresh from env
  if (url.pathname === '/api/refresh-env' && req.method === 'POST') {
    const envKey = getEnvKey();
    if (!envKey) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: '环境变量 MIMO_API_KEY 为空' }));
      return;
    }
    const keys = readKeys();
    const changes = [];
    if (keys.mimo !== envKey) {
      keys.mimo = envKey;
      changes.push('mimo: ' + maskKey(envKey));
    }
    writeKeys(keys);

    // Notify MiMoClaw
    try {
      const body = JSON.stringify(keys);
      const notifyReq = http.request({
        hostname: '127.0.0.1', port: MIMOCLAW_PORT, path: '/api/keys',
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
      }, () => {});
      notifyReq.on('error', () => {});
      notifyReq.setTimeout(2000, () => notifyReq.destroy());
      notifyReq.write(body);
      notifyReq.end();
    } catch (_) {}

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true, changes: changes.length ? changes : ['无变化'] }));
    return;
  }

  // API: Set key manually
  if (url.pathname === '/api/set-key' && req.method === 'POST') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      try {
        const { name, key } = JSON.parse(body);
        if (!name || !key) throw new Error('缺少 name 或 key');
        const keys = readKeys();
        keys[name] = key;
        writeKeys(keys);

        // Notify MiMoClaw
        try {
          const notifyBody = JSON.stringify(keys);
          const nr = http.request({
            hostname: '127.0.0.1', port: MIMOCLAW_PORT, path: '/api/keys',
            method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(notifyBody) }
          }, () => {});
          nr.on('error', () => {});
          nr.setTimeout(2000, () => nr.destroy());
          nr.write(notifyBody);
          nr.end();
        } catch (_) {}

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  // API: Test single key
  if (url.pathname === '/api/test-key' && req.method === 'POST') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', async () => {
      try {
        const { key, baseUrl, model } = JSON.parse(body);
        const result = await testKey(baseUrl || 'https://api.xiaomimimo.com/v1', key, model);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  // API: Test all keys
  if (url.pathname === '/api/test-all' && req.method === 'POST') {
    const keys = readKeys();
    const results = [];
    const tests = Object.keys(keys).map(async (name) => {
      const r = await testKey('https://api.xiaomimimo.com/v1', keys[name]);
      results.push({ name, ...r });
    });
    await Promise.all(tests);

    // Also test env key if different
    const envKey = getEnvKey();
    if (envKey && !Object.values(keys).includes(envKey)) {
      const r = await testKey('https://api.xiaomimimo.com/v1', envKey);
      results.push({ name: 'env (MIMO_API_KEY)', ...r });
    }

    // Update validity in key file
    results.forEach(r => {
      if (keys[r.name] !== undefined) {
        // Store validity status (optional, for future use)
      }
    });

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ results }));
    return;
  }

  res.writeHead(404);
  res.end('Not Found');
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('');
  console.log('🔑 MiMoClaw Key Manager');
  console.log('   http://localhost:' + PORT);
  console.log('');
  console.log('   功能:');
  console.log('   - 实时显示 Key 状态');
  console.log('   - 从环境变量刷新');
  console.log('   - 手动输入 Key');
  console.log('   - 检测 Key 可用性');
  console.log('   - 自动同步到 MiMoClaw');
  console.log('');
  
  // Auto open browser
  try {
    const cmd = process.platform === 'win32' ? 'start' : process.platform === 'darwin' ? 'open' : 'xdg-open';
    execSync(cmd + ' http://localhost:' + PORT, { stdio: 'ignore' });
  } catch (_) {}
});
