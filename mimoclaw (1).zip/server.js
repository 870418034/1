const express = require('express');
const multer = require('multer');
const AdmZip = require('adm-zip');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const https = require('https');
const { exec } = require('child_process');

const app = express();
const PORT = process.env.PORT || 3000;

// --- Dynamic Key Management ---
const KEY_FILE = path.join(__dirname, '.api_keys.json');

function loadApiKeys() {
  var keys = {};
  try { if (fs.existsSync(KEY_FILE)) keys = JSON.parse(fs.readFileSync(KEY_FILE, 'utf-8')); } catch (_) {}
  if (process.env.MIMO_API_KEY) keys.mimo = process.env.MIMO_API_KEY;
  return keys;
}
function getApiKey(modelId) {
  var keys = loadApiKeys();
  if (modelId && modelId.indexOf('mimo') !== -1) return keys.mimo || null;
  return keys[modelId] || null;
}

app.get('/api/keys', function(req, res) {
  var keys = loadApiKeys();
  var masked = {};
  Object.keys(keys).forEach(function(k) { var v = keys[k]; masked[k] = v ? (v.slice(0,8)+'...'+v.slice(-4)) : ''; });
  res.json({ keys: masked, raw: keys.mimo ? false : true });
});
app.post('/api/keys/refresh', function(req, res) {
  var envKey = process.env.MIMO_API_KEY || '';
  if (!envKey) return res.json({ ok: false, error: '环境变量 MIMO_API_KEY 为空' });
  var existing = {};
  try { existing = JSON.parse(fs.readFileSync(KEY_FILE, 'utf-8')); } catch (_) {}
  existing.mimo = envKey;
  fs.writeFileSync(KEY_FILE, JSON.stringify(existing, null, 2), 'utf-8');
  res.json({ ok: true, key: envKey.slice(0,8)+'...'+envKey.slice(-4) });
});
app.post('/api/keys', function(req, res) {
  var body = req.body;
  if (!body || typeof body !== 'object') return res.status(400).json({ error: 'invalid body' });
  try {
    var existing = {};
    try { existing = JSON.parse(fs.readFileSync(KEY_FILE, 'utf-8')); } catch (_) {}
    Object.assign(existing, body);
    fs.writeFileSync(KEY_FILE, JSON.stringify(existing, null, 2), 'utf-8');
    res.json({ ok: true, keys: Object.keys(existing) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// --- Config ---
const DEFAULT_CONFIG = {
  models: [
    { id: 'mimo-1', name: 'MiMo-A', baseUrl: 'https://api.xiaomimimo.com/v1', apiKey: '', model: 'mimo-v2-pro', enabled: true },
    { id: 'mimo-2', name: 'MiMo-B', baseUrl: 'https://api.xiaomimimo.com/v1', apiKey: '', model: 'mimo-v2-pro', enabled: true },
  ],
  mode: 'single', debateRounds: 2, parallelLimit: 2
};
let config = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
const realApiKeys = {};
DEFAULT_CONFIG.models.forEach(function(m) { realApiKeys[m.id] = m.apiKey; });

// --- Middleware ---
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// --- Upload ---
const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const storage = multer.diskStorage({
  destination: function(req, file, cb) { cb(null, UPLOAD_DIR); },
  filename: function(req, file, cb) { cb(null, 'upload_' + Date.now() + '_' + file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_')); }
});
const upload = multer({ storage: storage, limits: { fileSize: 200 * 1024 * 1024 } });

// --- Projects ---
const projects = new Map();

// --- Change History (per project) ---
const changeHistory = new Map();

// --- Templates ---
const TEMPLATES = {
  'react-app': { name: 'React 应用', desc: 'React + Vite + TypeScript 前端项目', tech: 'React + TypeScript + Vite' },
  'express-api': { name: 'Express API', desc: 'Node.js RESTful API 服务', tech: 'Node.js + Express' },
  'vue-app': { name: 'Vue 3 应用', desc: 'Vue 3 + Vite 前端项目', tech: 'Vue 3 + TypeScript + Vite' },
  'python-flask': { name: 'Flask Web', desc: 'Python Flask Web 应用', tech: 'Python + Flask' },
  'next-app': { name: 'Next.js 全栈', desc: 'Next.js 全栈应用', tech: 'Next.js + TypeScript' },
  'cli-tool': { name: 'CLI 工具', desc: 'Node.js 命令行工具', tech: 'Node.js + Commander' },
  'static-site': { name: '静态网站', desc: '纯 HTML/CSS/JS 网站', tech: 'HTML + CSS + JavaScript' },
  'discord-bot': { name: 'Discord Bot', desc: 'Discord 机器人', tech: 'Node.js + discord.js' },
  'electron-app': { name: 'Electron 桌面', desc: 'Electron 桌面应用', tech: 'Electron + React' },
  'chrome-ext': { name: 'Chrome 插件', desc: 'Chrome 浏览器扩展', tech: 'JavaScript + Chrome API' }
};

// --- Tools ---
const TOOLS = [
  { type: 'function', function: { name: 'read_file', description: '读取文件内容', parameters: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] } } },
  { type: 'function', function: { name: 'write_file', description: '写入/修改/覆盖文件内容', parameters: { type: 'object', properties: { path: { type: 'string' }, content: { type: 'string' } }, required: ['path', 'content'] } } },
  { type: 'function', function: { name: 'list_files', description: '列出目录', parameters: { type: 'object', properties: { dir: { type: 'string', default: '.' } } } } },
  { type: 'function', function: { name: 'create_file', description: '创建新文件', parameters: { type: 'object', properties: { path: { type: 'string' }, content: { type: 'string' } }, required: ['path', 'content'] } } },
  { type: 'function', function: { name: 'delete_file', description: '删除文件', parameters: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] } } }
];

function getSystemPrompt(agentName, role) {
  var p = '你是 ' + agentName + '，一个会主动行动的 AI 编程助手。\n';
  if (role) p += '角色: ' + role + '\n';
  p += '\n## 核心原则: 你是行动者，不是评论者\n';
  p += '\n## 工作方式:\n';
  p += '1. 用户提出需求后，立刻用工具开始修改代码\n';
  p += '2. 先 list_files 了解项目结构\n';
  p += '3. read_file 读取需要修改的文件\n';
  p += '4. 发现问题后 **直接用 write_file 修复**\n';
  p += '5. 每次 write_file 后回复:\n';
  p += '   - ✅ 修复了什么\n   - 📝 改了哪个文件\n   - 🔧 怎么改的\n';
  p += '\n## 严格规则:\n';
  p += '- 🚫 禁止: 只描述问题不修复\n- 🚫 禁止: 改完文件后什么都不说\n';
  p += '- ✅ 必须: 发现问题 → write_file 修改 → 报告结果\n';
  p += '- write_file 覆盖整个文件，内容必须完整\n- 中文回复\n';
  return p;
}

// --- Helper Functions ---
function normalizeSlashes(p) { return p.replace(/\\/g, '/'); }
function resolveProjectPath(projectId, relPath) {
  var project = projects.get(projectId);
  if (!project) throw new Error('项目不存在');
  var normalizedRel = normalizeSlashes(path.normalize(relPath)).replace(/^(\.\.\/?)+/, '');
  var normalizedRoot = normalizeSlashes(project.rootPath);
  var fullPath = normalizeSlashes(path.join(project.rootPath, normalizedRel));
  if (!fullPath.startsWith(normalizedRoot)) throw new Error('路径越权: ' + relPath);
  return fullPath;
}
function safeJsonParse(str) { if (!str) return {}; try { return JSON.parse(str); } catch (_) { return {}; } }
function countFilesDeep(dir) {
  var count = 0;
  try {
    var items = fs.readdirSync(dir, { withFileTypes: true });
    for (var i = 0; i < items.length; i++) {
      if (items[i].isDirectory()) { if (['node_modules','.git','__pycache__','.next'].indexOf(items[i].name) === -1) count += countFilesDeep(path.join(dir, items[i].name)); }
      else count++;
    }
  } catch (_) {}
  return count;
}
function buildFileTreeStr(dir, prefix, depth) {
  prefix = prefix || ''; depth = depth || 0;
  if (depth > 4) return '';
  var skip = ['node_modules','.git','__pycache__','.next','dist','build','.DS_Store','uploads'];
  var result = '';
  try {
    var items = fs.readdirSync(dir, { withFileTypes: true })
      .filter(function(e) { return skip.indexOf(e.name) === -1; })
      .sort(function(a, b) { if (a.isDirectory() !== b.isDirectory()) return a.isDirectory() ? -1 : 1; return a.name.localeCompare(b.name); });
    for (var i = 0; i < items.length; i++) {
      var isLast = i === items.length - 1;
      var name = items[i].name + (items[i].isDirectory() ? '/' : '');
      result += prefix + (isLast ? '└── ' : '├── ') + name + '\n';
      if (items[i].isDirectory()) result += buildFileTreeStr(path.join(dir, items[i].name), prefix + (isLast ? '    ' : '│   '), depth + 1);
    }
  } catch (_) {}
  return result;
}
function sseWrite(res, data) {
  if (!res.writableEnded) try { res.write('data: ' + JSON.stringify(data) + '\n\n'); } catch (_) {}
}

// --- Tool Execution ---
function executeTool(projectId, toolName, args) {
  try {
    switch (toolName) {
      case 'list_files': {
        var dir = args.dir || '.';
        var fullDir = resolveProjectPath(projectId, dir);
        if (!fs.existsSync(fullDir)) return { error: '目录不存在: ' + dir };
        if (!fs.statSync(fullDir).isDirectory()) return { error: dir + ' 不是目录' };
        var entries = fs.readdirSync(fullDir, { withFileTypes: true })
          .filter(function(e) { return ['node_modules','.git','.DS_Store','__pycache__','.next','dist','build','uploads'].indexOf(e.name) === -1; })
          .map(function(e) { return { name: e.name, type: e.isDirectory() ? 'directory' : 'file', path: dir === '.' ? e.name : dir + '/' + e.name }; })
          .sort(function(a, b) { if (a.type !== b.type) return a.type === 'directory' ? -1 : 1; return a.name.localeCompare(b.name); });
        return { dir: dir, entries: entries };
      }
      case 'read_file': {
        var fullPath = resolveProjectPath(projectId, args.path);
        if (!fs.existsSync(fullPath)) return { error: '文件不存在: ' + args.path };
        var stat = fs.statSync(fullPath);
        if (stat.isDirectory()) return { error: args.path + ' 是目录' };
        if (stat.size > 2 * 1024 * 1024) return { error: '文件过大' };
        var ext = path.extname(args.path).toLowerCase();
        var binaryExts = ['.png','.jpg','.jpeg','.gif','.ico','.woff','.woff2','.ttf','.zip','.exe','.dll','.so','.mp4','.mp3','.wav','.pdf','.bin'];
        if (binaryExts.indexOf(ext) !== -1) return { error: '跳过二进制文件' };
        var content = fs.readFileSync(fullPath, 'utf-8');
        return { path: args.path, content: content, lines: content.split('\n').length, size: stat.size };
      }
      case 'write_file':
      case 'create_file': {
        var fullPath = resolveProjectPath(projectId, args.path);
        if (args.content === undefined || args.content === null) return { error: '缺少 content 参数' };
        var dir = path.dirname(fullPath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        var changeType = 'created';
        var oldContent = null;
        if (fs.existsSync(fullPath)) {
          changeType = 'modified';
          try { oldContent = fs.readFileSync(fullPath, 'utf-8'); if (oldContent === args.content) return { path: args.path, status: 'unchanged', message: '内容未变化' }; } catch (_) {}
        }
        fs.writeFileSync(fullPath, args.content, 'utf-8');
        if (!changeHistory.has(projectId)) changeHistory.set(projectId, []);
        changeHistory.get(projectId).push({ path: args.path, before: oldContent, after: args.content, timestamp: Date.now(), type: changeType });
        return { path: args.path, status: changeType, message: changeType === 'created' ? '已创建' : '已修改' };
      }
      case 'delete_file': {
        var fullPath = resolveProjectPath(projectId, args.path);
        if (!fs.existsSync(fullPath)) return { error: '文件不存在' };
        if (fs.statSync(fullPath).isDirectory()) return { error: '是目录' };
        var oldContent = null;
        try { oldContent = fs.readFileSync(fullPath, 'utf-8'); } catch (_) {}
        fs.unlinkSync(fullPath);
        if (!changeHistory.has(projectId)) changeHistory.set(projectId, []);
        changeHistory.get(projectId).push({ path: args.path, before: oldContent, after: null, timestamp: Date.now(), type: 'deleted' });
        return { path: args.path, status: 'deleted', message: '已删除' };
      }
      default: return { error: '未知工具: ' + toolName };
    }
  } catch (err) { return { error: err.message }; }
}

// --- MiMo API ---
function resolveApiKey(modelConfig) {
  if (modelConfig.id && modelConfig.id.indexOf('mimo') !== -1) {
    try {
      var cp = require('child_process');
      var pids = cp.execSync("pgrep -f 'openclaw-gatewa'", { encoding: 'utf-8', timeout: 3000 }).trim().split('\n');
      for (var pi = 0; pi < pids.length; pi++) {
        var ep = '/proc/' + pids[pi].trim() + '/environ';
        if (fs.existsSync(ep)) {
          var envs = fs.readFileSync(ep, 'utf-8').split('\0');
          for (var ei = 0; ei < envs.length; ei++) {
            if (envs[ei].indexOf('MIMO_API_KEY=') === 0) {
              var freshKey = envs[ei].slice('MIMO_API_KEY='.length);
              if (freshKey) {
                try { var keys = {}; try { keys = JSON.parse(fs.readFileSync(KEY_FILE,'utf-8')); } catch(_){} if (keys.mimo !== freshKey) { keys.mimo = freshKey; fs.writeFileSync(KEY_FILE, JSON.stringify(keys,null,2),'utf-8'); } } catch(_){}
                return freshKey;
              }
            }
          }
        }
      }
    } catch (_) {}
    if (process.env.MIMO_API_KEY) return process.env.MIMO_API_KEY;
    var dynamicKey = getApiKey(modelConfig.id);
    if (dynamicKey) return dynamicKey;
  }
  return modelConfig.apiKey;
}

function apiRequest(modelConfig, messages, tools, stream) {
  return new Promise(function(resolve, reject) {
    var body = JSON.stringify({
      model: modelConfig.model, messages: messages,
      tools: tools || undefined, tool_choice: tools ? 'auto' : undefined,
      stream: !!stream, temperature: 0.3, max_tokens: 8192
    });
    var urlStr = modelConfig.baseUrl;
    if (urlStr.indexOf('/chat/completions') === -1) urlStr = urlStr.replace(/\/+$/, '') + '/chat/completions';
    var url;
    try { url = new URL(urlStr); } catch (e) { return reject(new Error('无效 URL')); }
    var req = https.request({
      hostname: url.hostname, port: url.port || 443, path: url.pathname + url.search, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + modelConfig.apiKey, 'Content-Length': Buffer.byteLength(body) }
    }, function(res) {
      if (res.statusCode >= 400) { var d = ''; res.on('data', function(c){d+=c;}); res.on('end', function(){ reject(new Error('API '+res.statusCode+': '+d.slice(0,200))); }); return; }
      if (stream) { resolve(res); } else {
        var data = '';
        res.on('data', function(chunk) { data += chunk; });
        res.on('end', function() { try { resolve(JSON.parse(data)); } catch(e) { reject(new Error('解析失败')); } });
      }
    });
    req.on('error', reject);
    req.setTimeout(180000, function() { req.destroy(); reject(new Error('超时')); });
    req.write(body);
    req.end();
  });
}

function callModel(modelConfig, messages, tools) {
  var c = Object.assign({}, modelConfig, { apiKey: resolveApiKey(modelConfig) });
  return apiRequest(c, messages, tools, false).then(function(parsed) {
    if (parsed.choices) parsed.choices.forEach(function(ch) { if (ch.message && ch.message.reasoning_content) delete ch.message.reasoning_content; });
    return parsed;
  });
}

async function callModelStream(modelConfig, messages, tools, onChunk) {
  var c = Object.assign({}, modelConfig, { apiKey: resolveApiKey(modelConfig) });
  var res = await apiRequest(c, messages, tools, true);
  return new Promise(function(resolve, reject) {
    var buffer = '';
    res.on('data', function(chunk) {
      buffer += chunk.toString();
      var lines = buffer.split('\n');
      buffer = lines.pop();
      for (var i = 0; i < lines.length; i++) {
        var trimmed = lines[i].trim();
        if (!trimmed || trimmed.indexOf('data: ') !== 0) continue;
        var data = trimmed.slice(6);
        if (data === '[DONE]') continue;
        try {
          var parsed = JSON.parse(data);
          var delta = parsed.choices && parsed.choices[0] && parsed.choices[0].delta;
          if (!delta) continue;
          var filtered = {};
          if (delta.reasoning_content) filtered.reasoning_content = delta.reasoning_content;
          if (delta.content) filtered.content = delta.content;
          if (delta.tool_calls) filtered.tool_calls = delta.tool_calls;
          if (filtered.reasoning_content || filtered.content || filtered.tool_calls) onChunk(filtered);
        } catch (_) {}
      }
    });
    res.on('end', resolve);
    res.on('error', reject);
  });
}

// --- Agent Runners ---
async function runStreamingChat(modelConfig, projectId, conversation, res) {
  var turn = 0;
  while (turn < 10) {
    turn++;
    var assistantContent = '', toolCalls = [];
    try {
      await callModelStream(modelConfig, conversation, TOOLS, function(delta) {
        if (delta.reasoning_content) sseWrite(res, { type: 'thinking', thinking: delta.reasoning_content, text: delta.reasoning_content });
        if (delta.content) { assistantContent += delta.content; sseWrite(res, { type: 'content', content: delta.content, text: delta.content }); }
        if (delta.tool_calls) {
          for (var i = 0; i < delta.tool_calls.length; i++) {
            var tc = delta.tool_calls[i];
            var idx = typeof tc.index === 'number' ? tc.index : 0;
            if (!toolCalls[idx]) toolCalls[idx] = { id: '', type: 'function', function: { name: '', arguments: '' } };
            if (tc.id) toolCalls[idx].id = tc.id;
            if (tc.function && tc.function.name) toolCalls[idx].function.name = tc.function.name;
            if (tc.function && tc.function.arguments) toolCalls[idx].function.arguments += tc.function.arguments;
          }
        }
      });
    } catch (e) {
      try {
        var result = await callModel(modelConfig, conversation, TOOLS);
        var choice = result.choices && result.choices[0] && result.choices[0].message;
        if (!choice) { sseWrite(res, { type: 'error', error: e.message }); break; }
        assistantContent = choice.content || '';
        toolCalls = choice.tool_calls || [];
        if (assistantContent) sseWrite(res, { type: 'content', content: assistantContent, text: assistantContent });
      } catch (e2) { sseWrite(res, { type: 'error', error: 'API失败: ' + e2.message }); break; }
    }
    conversation.push({ role: 'assistant', content: assistantContent || null, tool_calls: toolCalls.length > 0 ? toolCalls.map(function(tc,i) { return { id: tc.id || 'call_'+i, type: 'function', function: { name: tc.function.name, arguments: tc.function.arguments } }; }) : undefined });
    if (toolCalls.length === 0) break;
    for (var i = 0; i < toolCalls.length; i++) {
      var tc = toolCalls[i], args = safeJsonParse(tc.function && tc.function.arguments), toolName = tc.function && tc.function.name;
      sseWrite(res, { type: 'tool_start', tool: toolName, name: toolName, args: args });
      var toolResult = executeTool(projectId, toolName, args);
      sseWrite(res, { type: 'tool_result', tool: toolName, name: toolName, result: toolResult });
      conversation.push({ role: 'tool', tool_call_id: tc.id || 'call_'+Math.random(), content: JSON.stringify(toolResult) });
    }
  }
  if (conversation.length > 50) { var sm = conversation[0], kept = conversation.slice(-40); conversation.length = 0; conversation.push(sm); kept.forEach(function(m){conversation.push(m);}); }
}

async function runAgentTurn(modelConfig, projectId, conversation, useTools) {
  var localConv = conversation.slice(), turns = 0, finalContent = '';
  while (turns < 8) {
    turns++;
    var result = await callModel(modelConfig, localConv, useTools ? TOOLS : undefined);
    var choice = result.choices && result.choices[0] && result.choices[0].message;
    if (!choice) break;
    finalContent = choice.content || '';
    var toolCalls = choice.tool_calls || [];
    localConv.push({ role: 'assistant', content: finalContent || null, tool_calls: toolCalls.length > 0 ? toolCalls : undefined });
    if (toolCalls.length === 0 || !useTools) break;
    for (var i = 0; i < toolCalls.length; i++) {
      var tc = toolCalls[i], args = safeJsonParse(tc.function && tc.function.arguments);
      var toolResult = executeTool(projectId, tc.function && tc.function.name, args);
      localConv.push({ role: 'tool', tool_call_id: tc.id, content: JSON.stringify(toolResult) });
    }
  }
  return { content: finalContent, conversation: localConv };
}

async function runAgentWithToolTracking(modelConfig, projectId, conversation, onEvent) {
  var turns = 0, finalContent = '';
  while (turns < 8) {
    turns++;
    var result = await callModel(modelConfig, conversation, TOOLS);
    var choice = result.choices && result.choices[0] && result.choices[0].message;
    if (!choice) break;
    var content = choice.content || '', toolCalls = choice.tool_calls || [];
    if (content) finalContent = content;
    conversation.push({ role: 'assistant', content: content || null, tool_calls: toolCalls.length > 0 ? toolCalls : undefined });
    if (toolCalls.length === 0) break;
    for (var i = 0; i < toolCalls.length; i++) {
      var tc = toolCalls[i], fn = tc.function || {}, args = safeJsonParse(fn.arguments);
      onEvent({ type: 'tool_start', name: fn.name, args: args });
      var toolResult = executeTool(projectId, fn.name, args);
      onEvent({ type: 'tool_result', name: fn.name, result: toolResult });
      conversation.push({ role: 'tool', tool_call_id: tc.id, content: JSON.stringify(toolResult) });
    }
  }
  if (!finalContent) {
    var ts = [];
    conversation.forEach(function(m) { if (m.role === 'assistant' && m.tool_calls) m.tool_calls.forEach(function(tc) { ts.push('🔧 ' + (tc.function ? tc.function.name : '?')); }); });
    finalContent = ts.length > 0 ? '已完成:\n' + ts.join('\n') : '分析完成';
  }
  return { content: finalContent, conversation: conversation };
}

// --- Parallel runner: same key, N concurrent tasks ---
async function runParallelAgents(models, projectId, baseMessage, res) {
  var limit = config.parallelLimit || 2;
  var results = [];
  for (var batch = 0; batch < models.length; batch += limit) {
    var batchModels = models.slice(batch, batch + limit);
    var batchResults = await Promise.all(batchModels.map(function(model) {
      return (async function() {
        sseWrite(res, { type: 'phase', phase: model.name + ' 工作中...' });
        var sysPrompt = getSystemPrompt(model.name);
        var proj = projects.get(projectId);
        if (proj) {
          var treeStr = buildFileTreeStr(proj.rootPath).slice(0, 4000);
          if (treeStr) sysPrompt += '\n\n## 项目文件结构\n```\n' + treeStr + '\n```';
        }
        var conv = [{ role: 'system', content: sysPrompt }, { role: 'user', content: baseMessage }];
        try {
          var r = await runAgentWithToolTracking(model, projectId, conv, function(evt) {
            sseWrite(res, { type: evt.type, tool: evt.name, name: evt.name, args: evt.args, result: evt.result, agent: model.name });
          });
          sseWrite(res, { type: 'proposal', agent: model.name, content: (r.content || '').slice(0, 500) });
          return { agent: model.name, modelId: model.id, content: r.content, conversation: r.conversation };
        } catch (e) {
          sseWrite(res, { type: 'error', error: model.name + ' 失败: ' + e.message });
          return { agent: model.name, modelId: model.id, content: model.name + ' 调用失败: ' + e.message, conversation: [] };
        }
      })();
    }));
    results = results.concat(batchResults);
  }
  return results.filter(function(r) { return r.content && r.content.indexOf('调用失败') === -1; });
}

// ==================== API ROUTES ====================

// Config
app.get('/api/config', function(req, res) {
  var safe = JSON.parse(JSON.stringify(config));
  safe.models.forEach(function(m) {
    if (m.apiKey && m.apiKey.length > 12) m.apiKey = m.apiKey.slice(0,4) + '****' + m.apiKey.slice(-4);
    m._masked = true;
  });
  res.json(safe);
});
app.post('/api/config', function(req, res) {
  var body = req.body;
  if (Array.isArray(body.models)) {
    body.models.forEach(function(m) {
      if (m.apiKey && m.apiKey.indexOf('****') !== -1 && realApiKeys[m.id]) m.apiKey = realApiKeys[m.id];
      else if (m.apiKey) realApiKeys[m.id] = m.apiKey;
    });
    config.models = body.models;
  }
  if (body.mode) config.mode = body.mode;
  if (body.debateRounds != null) config.debateRounds = parseInt(body.debateRounds) || 2;
  if (body.parallelLimit != null) config.parallelLimit = Math.max(1, Math.min(10, parseInt(body.parallelLimit) || 2));
  res.json({ ok: true });
});
app.post('/api/config/test', async function(req, res) {
  var b = req.body;
  if (!b.baseUrl || !b.model) return res.json({ ok: false, error: '缺少 baseUrl/model' });
  var apiKey = b.apiKey;
  if (!apiKey || apiKey === 'auto') { if (b.modelId) apiKey = getApiKey(b.modelId) || ''; if (!apiKey) { var f = config.models.find(function(m){return m.baseUrl===b.baseUrl&&m.model===b.model;}); if (f) apiKey = f.apiKey; } }
  if (apiKey && apiKey.indexOf('****') !== -1) { var f = config.models.find(function(m){return m.baseUrl===b.baseUrl&&m.model===b.model;}); if (f) apiKey = f.apiKey; }
  if (!apiKey) return res.json({ ok: false, error: 'Key 未配置' });
  try {
    var result = await callModel({ baseUrl: b.baseUrl, apiKey: apiKey, model: b.model, id: b.modelId }, [{ role: 'user', content: '只回复"连接成功"' }]);
    var content = result.choices && result.choices[0] && result.choices[0].message && result.choices[0].message.content;
    res.json({ ok: true, response: (content || '连接成功 (推理模式)').slice(0, 100) });
  } catch (err) { res.json({ ok: false, error: err.message }); }
});

// Upload - FIX: match frontend field name 'files' instead of 'file'
app.post('/api/upload', upload.array('files', 10000), function(req, res) {
  try {
    if (!req.files || req.files.length === 0) return res.status(400).json({ error: '没有上传文件' });
    var projectId = 'proj_' + Date.now();
    var projectRoot = path.join(UPLOAD_DIR, projectId);
    fs.mkdirSync(projectRoot, { recursive: true });

    // Handle multiple uploaded files (folder upload)
    var fileCount = 0;
    req.files.forEach(function(f) {
      var relPath = f.originalname;
      var destPath = path.join(projectRoot, relPath);
      var destDir = path.dirname(destPath);
      if (!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive: true });
      // If it's a zip, extract it
      if (f.originalname.endsWith('.zip') || f.mimetype === 'application/zip') {
        try {
          var zip = new AdmZip(f.path);
          zip.extractAllTo(projectRoot, true);
          fileCount += countFilesDeep(projectRoot);
        } catch (_) {}
      } else {
        fs.renameSync(f.path, destPath);
        fileCount++;
      }
    });

    // Clean up temp files
    req.files.forEach(function(f) { try { if (fs.existsSync(f.path)) fs.unlinkSync(f.path); } catch (_) {} });

    var rootPath = projectRoot;
    try { var entries = fs.readdirSync(projectRoot, { withFileTypes: true }); if (entries.length === 1 && entries[0].isDirectory()) rootPath = path.join(projectRoot, entries[0].name); } catch (_) {}
    var projectName = req.body.name || path.basename(req.files[0].originalname, '.zip');
    if (fileCount === 0) fileCount = countFilesDeep(rootPath);

    projects.set(projectId, { id: projectId, name: projectName, rootPath: rootPath, fileCount: fileCount, conversations: {}, createdAt: Date.now() });
    res.json({ projectId: projectId, name: projectName, fileCount: fileCount, message: '上传成功' });
    console.log('[上传] ' + projectName + ' (' + fileCount + ' 文件)');
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Chat - Single
app.post('/api/chat', async function(req, res) {
  try {
    var body = req.body;
    if (!body.projectId || !body.message) return res.status(400).json({ error: '缺少参数' });
    var project = projects.get(body.projectId);
    if (!project) return res.status(404).json({ error: '项目不存在' });
    var model = config.models.find(function(m) { return m.id === body.modelId && m.enabled; }) || config.models.find(function(m) { return m.enabled; });
    if (!model) return res.status(400).json({ error: '没有可用模型' });
    if (!project.conversations[model.id]) {
      var sysPrompt = getSystemPrompt(model.name);
      if (!project._treeStr) try { project._treeStr = buildFileTreeStr(project.rootPath).slice(0, 4000); } catch (_) {}
      if (project._treeStr) sysPrompt += '\n\n## 项目文件结构\n```\n' + project._treeStr + '\n```';
      project.conversations[model.id] = [{ role: 'system', content: sysPrompt }];
    }
    var conv = project.conversations[model.id];
    conv.push({ role: 'user', content: body.message });
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
    await runStreamingChat(model, body.projectId, conv, res);
    res.end();
  } catch (err) { if (!res.headersSent) res.status(500).json({ error: err.message }); else { sseWrite(res, {type:'error',error:err.message}); res.end(); } }
});

// Chat - Multi (parallel)
app.post('/api/chat-multi', async function(req, res) {
  try {
    var body = req.body;
    if (!body.projectId || !body.message) return res.status(400).json({ error: '缺少参数' });
    var project = projects.get(body.projectId);
    if (!project) return res.status(404).json({ error: '项目不存在' });
    var enabledModels = config.models.filter(function(m) { return m.enabled; });
    if (enabledModels.length < 2) return res.status(400).json({ error: '多AI至少2个模型' });
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
    sseWrite(res, { type: 'phase', phase: 'discuss', message: '📢 并行分析 (并发: ' + (config.parallelLimit || 2) + ')' });
    var proposals = await runParallelAgents(enabledModels, body.projectId, body.message, res);
    if (proposals.length === 0) { sseWrite(res, { type: 'error', error: '所有模型调用失败' }); res.end(); return; }
    if (config.mode === 'debate' && config.debateRounds > 0) {
      sseWrite(res, { type: 'phase', phase: 'debate', message: '🔄 互相评审中...' });
      for (var round = 0; round < config.debateRounds; round++) {
        for (var i = 0; i < proposals.length; i++) {
          var model = enabledModels.find(function(m) { return m.id === proposals[i].modelId; });
          if (!model) continue;
          var others = proposals.filter(function(_, j) { return j !== i; });
          sseWrite(res, { type: 'phase', phase: model.name + ' 评审中...' });
          var prompt = '其他AI方案:\n\n' + others.map(function(p) { return '### ' + p.agent + ':\n' + p.content; }).join('\n\n') + '\n\n请改进你的方案。';
          var conv = proposals[i].conversation.slice();
          conv.push({ role: 'user', content: prompt });
          var result = await runAgentTurn(model, body.projectId, conv, false);
          proposals[i].content = result.content;
          sseWrite(res, { type: 'review', agent: model.name, content: (result.content || '').slice(0, 300) });
        }
      }
    }
    sseWrite(res, { type: 'phase', phase: 'synthesize', message: '🧠 综合最优方案...' });
    var arbiter = enabledModels[0];
    var finalPrompt = '各AI方案:\n\n' + proposals.map(function(p) { return '### ' + p.agent + ':\n' + p.content; }).join('\n\n') + '\n\n请综合最佳方案并执行修改。';
    var finalKey = arbiter.id + '_final';
    if (!project.conversations[finalKey]) project.conversations[finalKey] = [{ role: 'system', content: getSystemPrompt(arbiter.name + '(仲裁)', '综合多AI方案') }];
    project.conversations[finalKey].push({ role: 'user', content: finalPrompt });
    await runStreamingChat(arbiter, body.projectId, project.conversations[finalKey], res);
    sseWrite(res, { type: 'phase', phase: 'done', message: '✅ 多AI协作完成' });
    res.end();
  } catch (err) { if (!res.headersSent) res.status(500).json({ error: err.message }); else { sseWrite(res,{type:'error',error:err.message}); res.end(); } }
});

// Create Project
app.post('/api/create-project', async function(req, res) {
  try {
    var body = req.body;
    if (!body.name || !body.requirements) return res.status(400).json({ error: '缺少名称或需求' });
    var projectId = 'proj_' + Date.now();
    var projectRoot = path.join(UPLOAD_DIR, projectId);
    fs.mkdirSync(projectRoot, { recursive: true });
    var projectName = body.name.replace(/[^a-zA-Z0-9\u4e00-\u9fff_\-]/g, '_');
    projects.set(projectId, { id: projectId, name: projectName, rootPath: projectRoot, fileCount: 0, conversations: {}, createdAt: Date.now(), isCreated: true });
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
    sseWrite(res, { type: 'phase', phase: 'plan', message: '📐 需求分析中...' });
    var model = config.models.find(function(m) { return m.id === body.modelId && m.enabled; }) || config.models.find(function(m) { return m.enabled; });
    if (!model) { sseWrite(res, { type: 'error', error: '没有可用模型' }); res.end(); return; }
    var sysPrompt = '你是 ' + projectName + ' 的首席架构师。\n你的任务是根据需求从零创建完整项目。\n直接用 write_file 创建所有文件，项目要能直接运行。包含 package.json 和 README.md。中文回复，代码注释中文。';
    if (body.techStack) sysPrompt += '\n技术栈: ' + body.techStack;
    var conv = [{ role: 'system', content: sysPrompt }, { role: 'user', content: '项目名称: ' + projectName + '\n\n需求:\n' + body.requirements }];
    sseWrite(res, { type: 'phase', phase: 'generate', message: '🏗️ 生成文件中...' });
    await runStreamingChat(model, projectId, conv, res);
    var fileCount = countFilesDeep(projectRoot);
    var proj = projects.get(projectId);
    if (proj) proj.fileCount = fileCount;
    sseWrite(res, { type: 'phase', phase: 'done', message: '✅ 创建完成，' + fileCount + ' 个文件' });
    sseWrite(res, { type: 'project_ready', projectId: projectId, name: projectName, fileCount: fileCount });
    res.end();
  } catch (err) { if (!res.headersSent) res.status(500).json({ error: err.message }); else { sseWrite(res,{type:'error',error:err.message}); res.end(); } }
});

// Review Project
app.post('/api/review-project', async function(req, res) {
  try {
    var body = req.body;
    if (!body.projectId) return res.status(400).json({ error: '缺少 projectId' });
    var project = projects.get(body.projectId);
    if (!project) return res.status(404).json({ error: '项目不存在' });
    var model = config.models.find(function(m) { return m.id === body.modelId && m.enabled; }) || config.models.find(function(m) { return m.enabled; });
    if (!model) return res.status(400).json({ error: '没有可用模型' });
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
    sseWrite(res, { type: 'phase', phase: 'review', message: '🔍 审查中...' });
    var treeStr = buildFileTreeStr(project.rootPath).slice(0, 4000);
    var sysPrompt = getSystemPrompt(model.name, '审查专家');
    if (treeStr) sysPrompt += '\n\n## 项目结构\n```\n' + treeStr + '\n```';
    var prompt = '全面审查项目: 代码质量、安全、逻辑错误、性能、最佳实践、依赖。\n先 list_files，再 read_file 检查关键文件，发现问题直接 write_file 修复，最终输出报告。用✅❌⚠️标记。';
    var conv = [{ role: 'system', content: sysPrompt }, { role: 'user', content: prompt }];
    await runStreamingChat(model, body.projectId, conv, res);
    sseWrite(res, { type: 'phase', phase: 'done', message: '✅ 审查完成' });
    res.end();
  } catch (err) { if (!res.headersSent) res.status(500).json({ error: err.message }); else { sseWrite(res,{type:'error',error:err.message}); res.end(); } }
});

// Test Project
app.post('/api/test-project', async function(req, res) {
  try {
    var body = req.body;
    if (!body.projectId) return res.status(400).json({ error: '缺少 projectId' });
    var project = projects.get(body.projectId);
    if (!project) return res.status(404).json({ error: '项目不存在' });
    var model = config.models.find(function(m) { return m.id === body.modelId && m.enabled; }) || config.models.find(function(m) { return m.enabled; });
    if (!model) return res.status(400).json({ error: '没有可用模型' });
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
    sseWrite(res, { type: 'phase', phase: 'test', message: '🧪 测试中...' });
    var treeStr = buildFileTreeStr(project.rootPath).slice(0, 4000);
    var sysPrompt = getSystemPrompt(model.name, '测试工程师');
    if (treeStr) sysPrompt += '\n\n## 项目结构\n```\n' + treeStr + '\n```';
    var prompt = '测试项目: 功能完整性、边界条件、错误处理、集成问题。\nread_file 检查逻辑，发现 bug 直接 write_file 修复，输出测试报告。用✅❌⚠️标记。';
    var conv = [{ role: 'system', content: sysPrompt }, { role: 'user', content: prompt }];
    await runStreamingChat(model, body.projectId, conv, res);
    sseWrite(res, { type: 'phase', phase: 'done', message: '✅ 测试完成' });
    res.end();
  } catch (err) { if (!res.headersSent) res.status(500).json({ error: err.message }); else { sseWrite(res,{type:'error',error:err.message}); res.end(); } }
});

// ==================== ENHANCED FEATURES ====================

// 1. Global Search
app.get('/api/project/:id/search', function(req, res) {
  try {
    var q = req.query.q;
    if (!q) return res.status(400).json({ error: '缺少搜索词' });
    var projectId = req.params.id;
    var project = projects.get(projectId);
    if (!project) return res.status(404).json({ error: '项目不存在' });
    var results = [];
    var skip = ['node_modules','.git','__pycache__','.next','dist','build'];
    function searchDir(dir) {
      try {
        var items = fs.readdirSync(dir, { withFileTypes: true });
        for (var i = 0; i < items.length; i++) {
          if (skip.indexOf(items[i].name) !== -1) continue;
          var full = path.join(dir, items[i].name);
          if (items[i].isDirectory()) { searchDir(full); continue; }
          try {
            var stat = fs.statSync(full);
            if (stat.size > 1024 * 1024) continue;
            var ext = path.extname(items[i].name).toLowerCase();
            var binExts = ['.png','.jpg','.gif','.zip','.exe','.dll','.so','.mp4','.mp3','.pdf','.bin','.woff','.woff2','.ttf'];
            if (binExts.indexOf(ext) !== -1) continue;
            var content = fs.readFileSync(full, 'utf-8');
            var lines = content.split('\n');
            var relPath = path.relative(project.rootPath, full);
            for (var li = 0; li < lines.length; li++) {
              if (lines[li].indexOf(q) !== -1) {
                results.push({ file: relPath, line: li + 1, text: lines[li].trim().slice(0, 200), match: q });
                if (results.length >= 200) return;
              }
            }
          } catch (_) {}
        }
      } catch (_) {}
    }
    searchDir(project.rootPath);
    res.json({ query: q, count: results.length, results: results });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 2. Project Stats
app.get('/api/project/:id/stats', function(req, res) {
  try {
    var project = projects.get(req.params.id);
    if (!project) return res.status(404).json({ error: '项目不存在' });
    var stats = { totalFiles: 0, totalLines: 0, totalSize: 0, byType: {} };
    var skip = ['node_modules','.git','__pycache__','.next','dist','build'];
    function walk(dir) {
      try {
        var items = fs.readdirSync(dir, { withFileTypes: true });
        for (var i = 0; i < items.length; i++) {
          if (skip.indexOf(items[i].name) !== -1) continue;
          var full = path.join(dir, items[i].name);
          if (items[i].isDirectory()) { walk(full); continue; }
          try {
            var stat = fs.statSync(full);
            stats.totalFiles++;
            stats.totalSize += stat.size;
            var ext = path.extname(items[i].name).toLowerCase() || '(无后缀)';
            if (!stats.byType[ext]) stats.byType[ext] = { files: 0, lines: 0, size: 0 };
            stats.byType[ext].files++;
            stats.byType[ext].size += stat.size;
            if (stat.size < 1024 * 1024) {
              try {
                var lines = fs.readFileSync(full, 'utf-8').split('\n').length;
                stats.totalLines += lines;
                stats.byType[ext].lines += lines;
              } catch (_) {}
            }
          } catch (_) {}
        }
      } catch (_) {}
    }
    walk(project.rootPath);
    res.json(stats);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 3. Change History
app.get('/api/project/:id/history', function(req, res) {
  var history = changeHistory.get(req.params.id) || [];
  var summary = history.map(function(h, i) {
    return { index: i, path: h.path, type: h.type, time: new Date(h.timestamp).toLocaleString('zh-CN'), hasBefore: !!h.before, timestamp: h.timestamp };
  });
  res.json({ count: history.length, changes: summary });
});

// 4. Undo Change (FIX: support index-based undo, not just pop)
app.post('/api/project/:id/undo', function(req, res) {
  try {
    var history = changeHistory.get(req.params.id);
    if (!history || history.length === 0) return res.json({ ok: false, error: '没有可撤销的更改' });
    var idx = req.body && req.body.index != null ? parseInt(req.body.index) : history.length - 1;
    if (idx < 0 || idx >= history.length) idx = history.length - 1;
    var change = history.splice(idx, 1)[0];
    var fullPath;
    try { fullPath = resolveProjectPath(req.params.id, change.path); } catch (_) {
      // If path resolution fails, try using project root directly
      var project = projects.get(req.params.id);
      if (project) fullPath = path.join(project.rootPath, change.path);
      else return res.json({ ok: false, error: '项目不存在' });
    }
    if (change.type === 'created') {
      try { fs.unlinkSync(fullPath); } catch (_) {}
      res.json({ ok: true, action: 'removed', path: change.path });
    } else if (change.type === 'deleted') {
      if (change.before) {
        var dir = path.dirname(fullPath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(fullPath, change.before, 'utf-8');
        res.json({ ok: true, action: 'restored', path: change.path });
      } else {
        res.json({ ok: false, error: '没有旧内容可恢复' });
      }
    } else {
      if (change.before !== null) {
        fs.writeFileSync(fullPath, change.before, 'utf-8');
        res.json({ ok: true, action: 'reverted', path: change.path });
      } else {
        res.json({ ok: false, error: '没有旧内容可恢复' });
      }
    }
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 5. Diff (compare AI changes - FIX: generate proper unified diff)
app.get('/api/project/:id/diff', function(req, res) {
  var history = changeHistory.get(req.params.id) || [];
  // Generate unified diff format for last 20 changes
  var diffOutput = '';
  history.slice(-20).forEach(function(h) {
    diffOutput += '--- a/' + h.path + '\n+++ b/' + h.path + '\n';
    if (h.type === 'created') {
      diffOutput += '@@ -0,0 +1,' + (h.after ? h.after.split('\n').length : 0) + ' @@\n';
      if (h.after) h.after.split('\n').forEach(function(l) { diffOutput += '+' + l + '\n'; });
    } else if (h.type === 'deleted') {
      diffOutput += '@@ -1,' + (h.before ? h.before.split('\n').length : 0) + ' +0,0 @@\n';
      if (h.before) h.before.split('\n').forEach(function(l) { diffOutput += '-' + l + '\n'; });
    } else {
      var oldLines = (h.before || '').split('\n');
      var newLines = (h.after || '').split('\n');
      var maxLines = Math.min(Math.max(oldLines.length, newLines.length), 100);
      diffOutput += '@@ -1,' + oldLines.length + ' +1,' + newLines.length + ' @@\n';
      for (var i = 0; i < maxLines; i++) {
        var ol = oldLines[i] !== undefined ? oldLines[i] : '';
        var nl = newLines[i] !== undefined ? newLines[i] : '';
        if (ol === nl) diffOutput += ' ' + ol + '\n';
        else {
          if (ol) diffOutput += '-' + ol + '\n';
          if (nl) diffOutput += '+' + nl + '\n';
        }
      }
    }
    diffOutput += '\n';
  });
  res.json({ count: history.length, diff: diffOutput });
});

// 6. Templates List (FIX: return array directly for frontend compatibility)
app.get('/api/templates', function(req, res) {
  var list = Object.keys(TEMPLATES).map(function(k) { return { id: k, name: TEMPLATES[k].name, desc: TEMPLATES[k].desc, tech: TEMPLATES[k].tech }; });
  res.json(list);
});

// 7. Terminal Execute
app.post('/api/project/:id/exec', function(req, res) {
  try {
    var project = projects.get(req.params.id);
    if (!project) return res.status(404).json({ error: '项目不存在' });
    var cmd = (req.body.cmd || '').trim();
    if (!cmd) return res.status(400).json({ error: '缺少命令' });
    var blocked = ['rm -rf /','mkfs','dd if=','shutdown','reboot','passwd','useradd','chmod 777','curl.*|.*sh','wget.*|.*sh','nc -e','bash -i'];
    for (var bi = 0; bi < blocked.length; bi++) {
      if (cmd.indexOf(blocked[bi]) !== -1) return res.json({ ok: false, stdout: '', stderr: '命令被阻止: 危险操作' });
    }
    var allowed = ['npm','node','python','pip','ls','cat','head','tail','grep','find','wc','echo','mkdir','git','npx','yarn','pnpm','make','cargo','go','cp','mv','touch','tree','du','sort','uniq','diff','chmod','which','env','printenv','tsc','eslint','prettier'];
    var firstWord = cmd.split(/\s/)[0];
    if (allowed.indexOf(firstWord) === -1 && firstWord.indexOf('/') === -1) {
      return res.json({ ok: false, stdout: '', stderr: '不允许的命令: ' + firstWord + '。允许: ' + allowed.join(', ') });
    }
    exec(cmd, { cwd: project.rootPath, timeout: 30000, maxBuffer: 1024 * 1024 }, function(err, stdout, stderr) {
      res.json({ ok: !err, stdout: (stdout || '').slice(0, 10000), stderr: (stderr || '').slice(0, 5000), code: err ? err.code : 0 });
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 8. Code Format (AI-powered beautify)
app.post('/api/project/:id/format', async function(req, res) {
  try {
    var body = req.body;
    if (!body.path) return res.status(400).json({ error: '缺少文件路径' });
    var project = projects.get(req.params.id);
    if (!project) return res.status(404).json({ error: '项目不存在' });
    var fullPath = resolveProjectPath(req.params.id, body.path);
    if (!fs.existsSync(fullPath)) return res.status(404).json({ error: '文件不存在' });
    var content = fs.readFileSync(fullPath, 'utf-8');
    var model = config.models.find(function(m) { return m.enabled; });
    if (!model) return res.status(400).json({ error: '没有可用模型' });
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
    sseWrite(res, { type: 'phase', phase: 'format', message: '🎨 格式化中...' });
    var conv = [
      { role: 'system', content: '你是代码格式化专家。将用户提供的代码美化：修正缩进、统一风格、改善可读性。只输出美化后的完整代码，不要解释。' },
      { role: 'user', content: '请格式化以下 ' + path.extname(body.path) + ' 文件:\n\n```' + content + '```' }
    ];
    var result = await callModel(model, conv);
    var formatted = result.choices && result.choices[0] && result.choices[0].message && result.choices[0].message.content;
    if (formatted) {
      var codeMatch = formatted.match(/```(?:\w*\n)?([\s\S]*?)```/);
      if (codeMatch) formatted = codeMatch[1].trim();
      if (!changeHistory.has(req.params.id)) changeHistory.set(req.params.id, []);
      changeHistory.get(req.params.id).push({ path: body.path, before: content, after: formatted, timestamp: Date.now(), type: 'modified' });
      fs.writeFileSync(fullPath, formatted, 'utf-8');
      sseWrite(res, { type: 'content', content: '✅ 已格式化 ' + body.path, text: '✅ 已格式化 ' + body.path });
    }
    sseWrite(res, { type: 'phase', phase: 'done', message: '✅ 格式化完成' });
    res.end();
  } catch (err) { if (!res.headersSent) res.status(500).json({ error: err.message }); else { sseWrite(res,{type:'error',error:err.message}); res.end(); } }
});

// 9. Dependency Analysis (FIX: return deps as objects not arrays for frontend)
app.get('/api/project/:id/deps', function(req, res) {
  try {
    var project = projects.get(req.params.id);
    if (!project) return res.status(404).json({ error: '项目不存在' });
    var result = { name: null, version: null, dependencies: {}, devDependencies: {}, hasLock: false, requirements: null };
    var pkgPath = path.join(project.rootPath, 'package.json');
    if (fs.existsSync(pkgPath)) {
      var pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf-8'));
      result.name = pkg.name;
      result.version = pkg.version;
      result.scripts = pkg.scripts || {};
      result.dependencies = pkg.dependencies || {};
      result.devDependencies = pkg.devDependencies || {};
      result.hasLock = fs.existsSync(path.join(project.rootPath, 'package-lock.json')) || fs.existsSync(path.join(project.rootPath, 'yarn.lock'));
    }
    var reqPath = path.join(project.rootPath, 'requirements.txt');
    if (fs.existsSync(reqPath)) {
      result.requirements = fs.readFileSync(reqPath, 'utf-8').split('\n').filter(function(l) { return l.trim() && l.trim()[0] !== '#'; }).map(function(l) { return l.trim(); });
    }
    var goPath = path.join(project.rootPath, 'go.mod');
    if (fs.existsSync(goPath)) {
      result.goMod = fs.readFileSync(goPath, 'utf-8').split('\n').filter(function(l) { return l.trim().indexOf('require') === 0 || l.trim().indexOf('github') === 0 || l.trim().indexOf('golang') === 0; }).slice(0, 30);
    }
    res.json(result);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 10. Batch Search & Replace
app.post('/api/project/:id/replace', function(req, res) {
  try {
    var body = req.body;
    if (!body.search || body.replace === undefined) return res.status(400).json({ error: '缺少 search/replace' });
    var project = projects.get(req.params.id);
    if (!project) return res.status(404).json({ error: '项目不存在' });
    var skip = ['node_modules','.git','__pycache__','.next','dist','build'];
    var changed = [], totalReplacements = 0;
    function walk(dir) {
      try {
        var items = fs.readdirSync(dir, { withFileTypes: true });
        for (var i = 0; i < items.length; i++) {
          if (skip.indexOf(items[i].name) !== -1) continue;
          var full = path.join(dir, items[i].name);
          if (items[i].isDirectory()) { walk(full); continue; }
          try {
            var stat = fs.statSync(full);
            if (stat.size > 1024 * 1024) continue;
            var ext = path.extname(items[i].name).toLowerCase();
            var binaryExts = ['.png','.jpg','.gif','.zip','.exe','.dll','.so','.mp4','.mp3','.pdf','.bin'];
            if (binaryExts.indexOf(ext) !== -1) continue;
            var content = fs.readFileSync(full, 'utf-8');
            if (content.indexOf(body.search) !== -1) {
              var relPath = path.relative(project.rootPath, full);
              var oldContent = content;
              var count = content.split(body.search).length - 1;
              content = content.split(body.search).join(body.replace);
              if (count > 0) {
                fs.writeFileSync(full, content, 'utf-8');
                changed.push({ file: relPath, count: count });
                totalReplacements += count;
                if (!changeHistory.has(req.params.id)) changeHistory.set(req.params.id, []);
                changeHistory.get(req.params.id).push({ path: relPath, before: oldContent, after: content, timestamp: Date.now(), type: 'modified' });
              }
            }
          } catch (_) {}
        }
      } catch (_) {}
    }
    walk(project.rootPath);
    res.json({ ok: true, count: totalReplacements, replaced: totalReplacements, totalReplacements: totalReplacements, filesChanged: changed.length, files: changed });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ==================== NEW FEATURES ====================

// 11. Save file from editor
app.post('/api/project/:id/file', function(req, res) {
  try {
    var body = req.body;
    if (!body.path) return res.status(400).json({ error: '缺少路径' });
    var fullPath = resolveProjectPath(req.params.id, body.path);
    var oldContent = null;
    if (fs.existsSync(fullPath)) {
      try { oldContent = fs.readFileSync(fullPath, 'utf-8'); } catch (_) {}
    }
    var dir = path.dirname(fullPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(fullPath, body.content || '', 'utf-8');
    if (!changeHistory.has(req.params.id)) changeHistory.set(req.params.id, []);
    changeHistory.get(req.params.id).push({ path: body.path, before: oldContent, after: body.content, timestamp: Date.now(), type: oldContent !== null ? 'modified' : 'created' });
    res.json({ ok: true, path: body.path });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 12. Delete file via API (FIX: missing endpoint)
app.delete('/api/project/:id/file', function(req, res) {
  try {
    var relPath = req.query.path;
    if (!relPath) return res.status(400).json({ error: '缺少 path 参数' });
    var fullPath = resolveProjectPath(req.params.id, relPath);
    if (!fs.existsSync(fullPath)) return res.status(404).json({ error: '文件不存在' });
    if (fs.statSync(fullPath).isDirectory()) return res.status(400).json({ error: '不能删除目录' });
    var oldContent = null;
    try { oldContent = fs.readFileSync(fullPath, 'utf-8'); } catch (_) {}
    fs.unlinkSync(fullPath);
    if (!changeHistory.has(req.params.id)) changeHistory.set(req.params.id, []);
    changeHistory.get(req.params.id).push({ path: relPath, before: oldContent, after: null, timestamp: Date.now(), type: 'deleted' });
    res.json({ ok: true, path: relPath });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 13. Rename file
app.post('/api/project/:id/rename', function(req, res) {
  try {
    var body = req.body;
    if (!body.from || !body.to) return res.status(400).json({ error: '缺少 from/to' });
    var fromPath = resolveProjectPath(req.params.id, body.from);
    var toPath = resolveProjectPath(req.params.id, body.to);
    if (!fs.existsSync(fromPath)) return res.status(404).json({ error: '源文件不存在' });
    var toDir = path.dirname(toPath);
    if (!fs.existsSync(toDir)) fs.mkdirSync(toDir, { recursive: true });
    var content = fs.readFileSync(fromPath, 'utf-8');
    fs.writeFileSync(toPath, content, 'utf-8');
    fs.unlinkSync(fromPath);
    if (!changeHistory.has(req.params.id)) changeHistory.set(req.params.id, []);
    changeHistory.get(req.params.id).push({ path: body.from, before: content, after: null, timestamp: Date.now(), type: 'deleted' });
    changeHistory.get(req.params.id).push({ path: body.to, before: null, after: content, timestamp: Date.now(), type: 'created' });
    res.json({ ok: true, from: body.from, to: body.to });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// 14. Project tree as text
app.get('/api/project/:id/tree', function(req, res) {
  try {
    var project = projects.get(req.params.id);
    if (!project) return res.status(404).json({ error: '项目不存在' });
    var treeStr = buildFileTreeStr(project.rootPath);
    res.json({ tree: treeStr, fileCount: countFilesDeep(project.rootPath) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// --- Project Endpoints ---
app.get('/api/projects', function(req, res) {
  var list = [];
  projects.forEach(function(p, id) { list.push({ id: id, name: p.name, createdAt: p.createdAt, fileCount: p.fileCount || 0 }); });
  res.json({ projects: list });
});
app.get('/api/project/:id', function(req, res) {
  var project = projects.get(req.params.id);
  if (!project) return res.status(404).json({ error: '项目不存在' });
  function buildTree(dir, relPath) {
    relPath = relPath || '';
    var entries = [];
    try {
      var items = fs.readdirSync(dir, { withFileTypes: true });
      for (var i = 0; i < items.length; i++) {
        if (['node_modules','.git','.DS_Store','__pycache__','.next'].indexOf(items[i].name) !== -1) continue;
        var itemRel = relPath ? relPath + '/' + items[i].name : items[i].name;
        if (items[i].isDirectory()) entries.push({ name: items[i].name, type: 'directory', path: itemRel, children: buildTree(path.join(dir, items[i].name), itemRel) });
        else { try { var stat = fs.statSync(path.join(dir, items[i].name)); entries.push({ name: items[i].name, type: 'file', path: itemRel, size: stat.size }); } catch (_) {} }
      }
    } catch (_) {}
    return entries.sort(function(a, b) { if (a.type !== b.type) return a.type === 'directory' ? -1 : 1; return a.name.localeCompare(b.name); });
  }
  res.json({ id: project.id, name: project.name, tree: buildTree(project.rootPath), isCreated: project.isCreated });
});
app.get('/api/project/:id/file', function(req, res) {
  try {
    var relPath = req.query.path;
    if (!relPath) return res.status(400).json({ error: '缺少 path' });
    var fullPath = resolveProjectPath(req.params.id, relPath);
    if (!fs.existsSync(fullPath)) return res.status(404).json({ error: '文件不存在' });
    if (fs.statSync(fullPath).isDirectory()) return res.status(400).json({ error: '是目录' });
    res.json({ path: relPath, content: fs.readFileSync(fullPath, 'utf-8') });
  } catch (err) { res.status(500).json({ error: err.message }); }
});
app.delete('/api/project/:id', function(req, res) {
  var project = projects.get(req.params.id);
  if (!project) return res.status(404).json({ error: '项目不存在' });
  try { fs.rmSync(project.rootPath, { recursive: true, force: true }); } catch (_) {}
  projects.delete(req.params.id);
  changeHistory.delete(req.params.id);
  res.json({ ok: true });
});
app.get('/api/project/:id/download', function(req, res) {
  var project = projects.get(req.params.id);
  if (!project) return res.status(404).json({ error: '项目不存在' });
  try {
    var zip = new AdmZip();
    zip.addLocalFolder(project.rootPath);
    res.set('Content-Type', 'application/zip');
    res.set('Content-Disposition', 'attachment; filename="' + encodeURIComponent(project.name) + '.zip"');
    res.send(zip.toBuffer());
  } catch (err) { res.status(500).json({ error: '打包失败' }); }
});
app.get('/api/health', function(req, res) {
  res.json({ status: 'ok', mode: config.mode, models: config.models.filter(function(m) { return m.enabled; }).length, projects: projects.size, parallelLimit: config.parallelLimit });
});

// SPA fallback
app.get('*', function(req, res) { res.sendFile(path.join(__dirname, 'public', 'index.html')); });

app.listen(PORT, '0.0.0.0', function() {
  var envKey = process.env.MIMO_API_KEY || '';
  if (!envKey) {
    try {
      var cp = require('child_process');
      var pids = cp.execSync("pgrep -f 'openclaw-gatewa'", { encoding: 'utf-8' }).trim().split('\n');
      for (var pi = 0; pi < pids.length; pi++) {
        var ep = '/proc/' + pids[pi].trim() + '/environ';
        if (fs.existsSync(ep)) {
          var envs = fs.readFileSync(ep, 'utf-8').split('\0');
          for (var ei = 0; ei < envs.length; ei++) { if (envs[ei].indexOf('MIMO_API_KEY=') === 0) { envKey = envs[ei].slice('MIMO_API_KEY='.length); break; } }
        }
        if (envKey) break;
      }
    } catch (_) {}
  }
  if (envKey) {
    var keys = {};
    try { keys = JSON.parse(fs.readFileSync(KEY_FILE, 'utf-8')); } catch (_) {}
    if (keys.mimo !== envKey) { keys.mimo = envKey; fs.writeFileSync(KEY_FILE, JSON.stringify(keys, null, 2), 'utf-8'); }
  }
  console.log('\n🐾 MiMoClaw v2.0 on http://localhost:' + PORT);
  console.log('   Mode: ' + config.mode + ' | Models: ' + config.models.filter(function(m) { return m.enabled; }).length + ' | Parallel: ' + (config.parallelLimit || 2));
  console.log('   Key: ' + (envKey ? (envKey.slice(0,8)+'...'+envKey.slice(-4)) : '⚠️ 未设置'));
  console.log('   Features: 14 (create/review/test/search/stats/history/undo/diff/templates/exec/format/deps/replace/save/rename/tree)\n');
});
