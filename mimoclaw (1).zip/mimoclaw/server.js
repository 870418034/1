const express = require('express');
const multer = require('multer');
const AdmZip = require('adm-zip');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const https = require('https');

const app = express();
const PORT = process.env.PORT || 3000;

// --- Dynamic Key Management ---
// Key refreshes every hour. Don't hardcode - read dynamically.
const KEY_FILE = path.join(__dirname, '.api_keys.json');

function loadApiKeys() {
  var keys = {};
  try {
    if (fs.existsSync(KEY_FILE)) {
      keys = JSON.parse(fs.readFileSync(KEY_FILE, 'utf-8'));
    }
  } catch (_) {}
  // Env var overrides file
  if (process.env.MIMO_API_KEY) keys.mimo = process.env.MIMO_API_KEY;
  return keys;
}

function getApiKey(modelId) {
  var keys = loadApiKeys();
  // MiMo-C and MiMo-D use the same refreshed key
  if (modelId === 'mimo-3' || modelId === 'mimo-4') {
    return keys.mimo || null;
  }
  return keys[modelId] || null;
}

// Key refresh endpoint - external tool can POST new keys here
app.get('/api/keys', function(req, res) {
  var keys = loadApiKeys();
  var masked = {};
  Object.keys(keys).forEach(function(k) {
    var v = keys[k];
    masked[k] = v ? (v.slice(0, 8) + '...' + v.slice(-4)) : '';
  });
  res.json({ keys: masked, raw: keys.mimo ? false : true });
});

app.post('/api/keys/refresh', function(req, res) {
  var envKey = process.env.MIMO_API_KEY || '';
  if (!envKey) return res.json({ ok: false, error: '环境变量 MIMO_API_KEY 为空' });
  var existing = {};
  try { existing = JSON.parse(fs.readFileSync(KEY_FILE, 'utf-8')); } catch (_) {}
  existing.mimo = envKey;
  fs.writeFileSync(KEY_FILE, JSON.stringify(existing, null, 2), 'utf-8');
  console.log('[Key] 手动刷新: ' + envKey.slice(0, 8) + '...' + envKey.slice(-4));
  res.json({ ok: true, key: envKey.slice(0, 8) + '...' + envKey.slice(-4) });
});

app.post('/api/keys', function(req, res) {
  var body = req.body;
  if (!body || typeof body !== 'object') return res.status(400).json({ error: 'invalid body' });
  try {
    var existing = {};
    try { existing = JSON.parse(fs.readFileSync(KEY_FILE, 'utf-8')); } catch (_) {}
    Object.assign(existing, body);
    fs.writeFileSync(KEY_FILE, JSON.stringify(existing, null, 2), 'utf-8');
    console.log('[Key] 已更新:', Object.keys(body).join(', '));
    res.json({ ok: true, keys: Object.keys(existing) });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// --- Default Config ---
const DEFAULT_CONFIG = {
  models: [
    { id: 'mimo-1', name: 'MiMo-A', baseUrl: 'https://token-plan-cn.xiaomimimo.com/v1', apiKey: '', model: 'mimo-v2-pro', enabled: true },
    { id: 'mimo-2', name: 'MiMo-B', baseUrl: 'https://token-plan-cn.xiaomimimo.com/v1', apiKey: '', model: 'mimo-v2-pro', enabled: true },
    { id: 'mimo-3', name: 'MiMo-C', baseUrl: 'https://api.xiaomimimo.com/v1', apiKey: '', model: 'mimo-v2-pro', enabled: true },
    { id: 'mimo-4', name: 'MiMo-D', baseUrl: 'https://api.xiaomimimo.com/v1', apiKey: '', model: 'mimo-v2-pro', enabled: true },
  ],
  mode: 'single',
  debateRounds: 2,
};
let config = JSON.parse(JSON.stringify(DEFAULT_CONFIG));

// Keep real API keys in memory for restore after masked save
const realApiKeys = {};
DEFAULT_CONFIG.models.forEach(m => { realApiKeys[m.id] = m.apiKey; });

// --- Middleware ---
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// --- Upload ---
const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => cb(null, 'upload_' + Date.now() + '.zip')
});
const upload = multer({ storage, limits: { fileSize: 200 * 1024 * 1024 } });

// --- Projects ---
const projects = new Map();

// --- AI Tools ---
const TOOLS = [
  { type: 'function', function: { name: 'read_file', description: '读取文件内容', parameters: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] } } },
  { type: 'function', function: { name: 'write_file', description: '写入/修改/覆盖文件内容', parameters: { type: 'object', properties: { path: { type: 'string' }, content: { type: 'string' } }, required: ['path', 'content'] } } },
  { type: 'function', function: { name: 'list_files', description: '列出目录', parameters: { type: 'object', properties: { dir: { type: 'string', default: '.' } } } } },
  { type: 'function', function: { name: 'create_file', description: '创建新文件', parameters: { type: 'object', properties: { path: { type: 'string' }, content: { type: 'string' } }, required: ['path', 'content'] } } },
  { type: 'function', function: { name: 'delete_file', description: '删除文件', parameters: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] } } }
];

function getSystemPrompt(agentName, role) {
  var p = '你是 ' + agentName + '，一个会主动行动的 AI 编程助手。\n';
  if (role) p += '角色: ' + role + '\n';
  p += '\n## 核心原则: 你是行动者，不是评论者\n';
  p += '\n## 你的工作方式:\n';
  p += '1. 用户提出需求后，立刻用工具开始修改代码\n';
  p += '2. 先 list_files 了解项目结构\n';
  p += '3. read_file 读取需要修改的文件\n';
  p += '4. 发现问题后 **直接用 write_file 修复**，不要只说"这里有问题"\n';
  p += '5. 每次 write_file 后，回复中必须包含：\n';
  p += '   - ✅ 修复了什么：具体问题描述\n';
  p += '   - 📝 改了哪个文件：文件路径\n';
  p += '   - 🔧 怎么改的：简要说明修改内容\n';
  p += '\n## 严格规则:\n';
  p += '- 🚫 禁止: 只描述问题不修复、让用户自己改、说"你应该改成..."\n';
  p += '- 🚫 禁止: 改完文件后什么都不说，用户不知道你做了什么\n';
  p += '- ✅ 必须: 发现 bug/问题/优化点 → 立即 write_file 修改 → 报告修改结果\n';
  p += '- 修改前必须 read_file 看当前完整内容\n';
  p += '- write_file 覆盖整个文件，内容必须完整\n';
  p += '- 保持原有代码风格和缩进\n';
  p += '- 中文回复\n';
  p += '\n## 示例:\n';
  p += '用户: "上传后一直显示分析中"\n';
  p += '❌ 错误做法: "这是因为前端没有监听后端完成状态，你应该加一个轮询接口..."\n';
  p += '✅ 正确做法: 直接 read_file → 找到问题 → write_file 修复 → 回复:\n';
  p += '  ✅ 修复了「上传后一直显示分析中」的问题\n';
  p += '  📝 修改文件: server.js\n';
  p += '  🔧 改动: 去掉了自动分析的后台任务，改为用户首次对话时再按需探索项目';
  return p;
}

// --- Safe path (cross-platform) ---
function normalizeSlashes(p) {
  return p.replace(/\\/g, '/');
}

function resolveProjectPath(projectId, relPath) {
  var project = projects.get(projectId);
  if (!project) throw new Error('项目不存在');
  var normalizedRel = normalizeSlashes(path.normalize(relPath)).replace(/^(\.\.\/?)+/, '');
  var normalizedRoot = normalizeSlashes(project.rootPath);
  var fullPath = normalizeSlashes(path.join(project.rootPath, normalizedRel));
  if (!fullPath.startsWith(normalizedRoot)) throw new Error('路径越权: ' + relPath);
  return fullPath;
}

// --- Tool execution ---
function executeTool(projectId, toolName, args) {
  try {
    switch (toolName) {
      case 'list_files': {
        var dir = args.dir || '.';
        var fullDir = resolveProjectPath(projectId, dir);
        if (!fs.existsSync(fullDir)) return { error: '目录不存在: ' + dir };
        if (!fs.statSync(fullDir).isDirectory()) return { error: dir + ' 不是目录' };
        var entries = fs.readdirSync(fullDir, { withFileTypes: true })
          .filter(function(e) { return ['node_modules', '.git', '.DS_Store', '__pycache__', '.next', 'dist', 'build', 'uploads'].indexOf(e.name) === -1; })
          .map(function(e) {
            return { name: e.name, type: e.isDirectory() ? 'directory' : 'file', path: dir === '.' ? e.name : dir + '/' + e.name };
          })
          .sort(function(a, b) {
            if (a.type !== b.type) return a.type === 'directory' ? -1 : 1;
            return a.name.localeCompare(b.name);
          });
        return { dir: dir, entries: entries };
      }
      case 'read_file': {
        var fullPath = resolveProjectPath(projectId, args.path);
        if (!fs.existsSync(fullPath)) return { error: '文件不存在: ' + args.path };
        var stat = fs.statSync(fullPath);
        if (stat.isDirectory()) return { error: args.path + ' 是目录，不是文件' };
        if (stat.size > 2 * 1024 * 1024) return { error: '文件过大 (' + (stat.size / 1024).toFixed(0) + 'KB)' };
        var ext = path.extname(args.path).toLowerCase();
        var binaryExts = ['.png', '.jpg', '.jpeg', '.gif', '.ico', '.woff', '.woff2', '.ttf', '.zip', '.exe', '.dll', '.so', '.dylib', '.mp4', '.mp3', '.wav', '.pdf', '.bin'];
        if (binaryExts.indexOf(ext) !== -1) return { error: '跳过二进制文件: ' + args.path };
        var content = fs.readFileSync(fullPath, 'utf-8');
        return { path: args.path, content: content, lines: content.split('\n').length, size: stat.size };
      }
      case 'write_file':
      case 'create_file': {
        var fullPath = resolveProjectPath(projectId, args.path);
        if (!args.content && args.content !== '') return { error: '缺少 content 参数' };
        var dir = path.dirname(fullPath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        var changeType = 'created';
        if (fs.existsSync(fullPath)) {
          changeType = 'modified';
          try {
            var old = fs.readFileSync(fullPath, 'utf-8');
            if (old === args.content) return { path: args.path, status: 'unchanged', message: '内容未变化' };
          } catch (_) {}
        }
        fs.writeFileSync(fullPath, args.content, 'utf-8');
        // Verify write
        try {
          var verify = fs.readFileSync(fullPath, 'utf-8');
          if (verify !== args.content) return { path: args.path, status: 'error', message: '写入验证失败' };
        } catch (_) {}
        return { path: args.path, status: changeType, message: changeType === 'created' ? '已创建' : '已修改' };
      }
      case 'delete_file': {
        var fullPath = resolveProjectPath(projectId, args.path);
        if (!fs.existsSync(fullPath)) return { error: '文件不存在: ' + args.path };
        if (fs.statSync(fullPath).isDirectory()) return { error: args.path + ' 是目录，不能用 delete_file 删除' };
        fs.unlinkSync(fullPath);
        return { path: args.path, status: 'deleted', message: '已删除' };
      }
      default:
        return { error: '未知工具: ' + toolName };
    }
  } catch (err) {
    return { error: err.message };
  }
}

// --- Build file tree string for system prompt injection ---
function buildFileTreeStr(dir, prefix, depth) {
  prefix = prefix || '';
  depth = depth || 0;
  if (depth > 4) return '';
  var skip = ['node_modules', '.git', '__pycache__', '.next', 'dist', 'build', '.DS_Store', 'uploads'];
  var result = '';
  try {
    var items = fs.readdirSync(dir, { withFileTypes: true })
      .filter(function(e) { return skip.indexOf(e.name) === -1; })
      .sort(function(a, b) {
        if (a.isDirectory() !== b.isDirectory()) return a.isDirectory() ? -1 : 1;
        return a.name.localeCompare(b.name);
      });
    for (var i = 0; i < items.length; i++) {
      var isLast = i === items.length - 1;
      var connector = isLast ? '└── ' : '├── ';
      var name = items[i].name;
      if (items[i].isDirectory()) name += '/';
      result += prefix + connector + name + '\n';
      if (items[i].isDirectory()) {
        var childPrefix = prefix + (isLast ? '    ' : '│   ');
        result += buildFileTreeStr(path.join(dir, items[i].name), childPrefix, depth + 1);
      }
    }
  } catch (_) {}
  return result;
}

// --- Safe JSON parse ---
function safeJsonParse(str) {
  if (!str) return {};
  try { return JSON.parse(str); } catch (_) { return {}; }
}

// --- MiMo API calls ---
function apiRequest(modelConfig, messages, tools, stream) {
  return new Promise(function(resolve, reject) {
    var body = JSON.stringify({
      model: modelConfig.model,
      messages: messages,
      tools: tools || undefined,
      tool_choice: tools ? 'auto' : undefined,
      stream: !!stream,
      temperature: 0.3,
      max_tokens: 8192
    });
    var urlStr = modelConfig.baseUrl;
    // Ensure URL ends with /chat/completions
    if (urlStr.indexOf('/chat/completions') === -1) {
      urlStr = urlStr.replace(/\/+$/, '') + '/chat/completions';
    }
    var url;
    try { url = new URL(urlStr); } catch (e) { return reject(new Error('无效的 Base URL: ' + urlStr)); }
    var req = https.request({
      hostname: url.hostname,
      port: url.port || 443,
      path: url.pathname + url.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + modelConfig.apiKey,
        'Content-Length': Buffer.byteLength(body)
      }
    }, function(res) {
      if (res.statusCode === 403) {
        var d = ''; res.on('data', function(c) { d += c; });
        res.on('end', function() { reject(new Error('API 403 权限错误: ' + d.slice(0, 200))); });
        return;
      }
      if (res.statusCode === 401) { reject(new Error('API Key 无效')); return; }
      if (res.statusCode >= 400) {
        var d = ''; res.on('data', function(c) { d += c; });
        res.on('end', function() { reject(new Error('API ' + res.statusCode + ': ' + d.slice(0, 200))); });
        return;
      }
      if (stream) {
        resolve(res);
      } else {
        var data = '';
        res.on('data', function(chunk) { data += chunk; });
        res.on('end', function() {
          try {
            var parsed = JSON.parse(data);
            if (parsed.error) return reject(new Error(parsed.error.message || JSON.stringify(parsed.error)));
            resolve(parsed);
          } catch (e) { reject(new Error('API 响应解析失败: ' + data.slice(0, 300))); }
        });
      }
    });
    req.on('error', reject);
    req.setTimeout(180000, function() { req.destroy(); reject(new Error('请求超时 (180s)')); });
    req.write(body);
    req.end();
  });
}

// Non-streaming call
// Resolve API key dynamically (handles hourly key refresh)
function resolveApiKey(modelConfig) {
  // MiMo-C and MiMo-D: always try freshest source first
  if (modelConfig.id === 'mimo-3' || modelConfig.id === 'mimo-4') {
    // 1. Try /proc (always fresh from OpenClaw gateway)
    try {
      var cp = require('child_process');
      var pids = cp.execSync("pgrep -f 'openclaw-gatewa'", { encoding: 'utf-8', timeout: 3000 }).trim().split('\n');
      for (var pi = 0; pi < pids.length; pi++) {
        var ep = '/proc/' + pids[pi].trim() + '/environ';
        if (fs.existsSync(ep)) {
          var envs = fs.readFileSync(ep, 'utf-8').split('\0');
          for (var ei = 0; ei < envs.length; ei++) {
            if (envs[ei].indexOf('MIMO_API_KEY=') === 0) {
              var freshKey = envs[ei].slice('MIMO_API_KEY='.length);
              if (freshKey) {
                // Update key file too
                try {
                  var keys = {};
                  try { keys = JSON.parse(fs.readFileSync(KEY_FILE, 'utf-8')); } catch (_) {}
                  if (keys.mimo !== freshKey) {
                    keys.mimo = freshKey;
                    fs.writeFileSync(KEY_FILE, JSON.stringify(keys, null, 2), 'utf-8');
                  }
                } catch (_) {}
                return freshKey;
              }
            }
          }
        }
      }
    } catch (_) {}
    // 2. Try env var
    if (process.env.MIMO_API_KEY) return process.env.MIMO_API_KEY;
    // 3. Try key file
    var dynamicKey = getApiKey(modelConfig.id);
    if (dynamicKey) return dynamicKey;
  }
  return modelConfig.apiKey;
}

// Auto-retry wrapper: on 401/403, force-refresh key from /proc and retry
function callModel(modelConfig, messages, tools) {
  var configWithKey = Object.assign({}, modelConfig, { apiKey: resolveApiKey(modelConfig) });
  return apiRequest(configWithKey, messages, tools, false).then(function(parsed) {
    if (parsed.choices) {
      for (var i = 0; i < parsed.choices.length; i++) {
        if (parsed.choices[i].message && parsed.choices[i].message.reasoning_content) {
          delete parsed.choices[i].message.reasoning_content;
        }
      }
    }
    return parsed;
  }).catch(function(err) {
    if ((err.message.indexOf('401') !== -1 || err.message.indexOf('403') !== -1) && modelConfig.id) {
      console.log('[Key] ⚠️ ' + (modelConfig.name || modelConfig.id) + ' 认证失败，强制刷新 key...');
      // Force fresh read from /proc
      delete require.cache[require.resolve('child_process')];
      try {
        var cp = require('child_process');
        var pids = cp.execSync("pgrep -f 'openclaw-gatewa'", { encoding: 'utf-8', timeout: 3000 }).trim().split('\n');
        for (var pi = 0; pi < pids.length; pi++) {
          var ep = '/proc/' + pids[pi].trim() + '/environ';
          if (fs.existsSync(ep)) {
            var envs = fs.readFileSync(ep, 'utf-8').split('\0');
            for (var ei = 0; ei < envs.length; ei++) {
              if (envs[ei].indexOf('MIMO_API_KEY=') === 0) {
                var freshKey = envs[ei].slice('MIMO_API_KEY='.length);
                if (freshKey && freshKey !== configWithKey.apiKey) {
                  console.log('[Key] ✅ 获取到新 key: ' + freshKey.slice(0, 8) + '...' + freshKey.slice(-4));
                  var retryConfig = Object.assign({}, modelConfig, { apiKey: freshKey });
                  // Update key file
                  try {
                    var keys = {};
                    try { keys = JSON.parse(fs.readFileSync(KEY_FILE, 'utf-8')); } catch (_) {}
                    keys.mimo = freshKey;
                    fs.writeFileSync(KEY_FILE, JSON.stringify(keys, null, 2), 'utf-8');
                  } catch (_) {}
                  return apiRequest(retryConfig, messages, tools, false).then(function(parsed) {
                    if (parsed.choices) {
                      for (var i = 0; i < parsed.choices.length; i++) {
                        if (parsed.choices[i].message && parsed.choices[i].message.reasoning_content) {
                          delete parsed.choices[i].message.reasoning_content;
                        }
                      }
                    }
                    return parsed;
                  });
                }
              }
            }
          }
        }
      } catch (e) { console.log('[Key] 刷新失败:', e.message); }
      console.log('[Key] ❌ 无法获取新 key');
    }
    throw err;
  });
}

// Streaming call with key refresh
async function callModelStream(modelConfig, messages, tools, onChunk) {
  var configWithKey = Object.assign({}, modelConfig, { apiKey: resolveApiKey(modelConfig) });
  var res;
  try {
    res = await apiRequest(configWithKey, messages, tools, true);
  } catch(err) {
    if ((err.message.indexOf('401') !== -1 || err.message.indexOf('403') !== -1) && modelConfig.id) {
      console.log('[Key] ' + modelConfig.name + ' key过期，刷新重试...');
      var freshKey = resolveApiKey(modelConfig);
      if (freshKey && freshKey !== configWithKey.apiKey) {
        var retryConfig = Object.assign({}, modelConfig, { apiKey: freshKey });
        res = await apiRequest(retryConfig, messages, tools, true);
      } else {
        throw err;
      }
    } else {
      throw err;
    }
  }
  return new Promise(function(resolve, reject) {
    var buffer = '';
    res.on('data', function(chunk) {
      buffer += chunk.toString();
      var lines = buffer.split('\n');
      buffer = lines.pop();
      for (var i = 0; i < lines.length; i++) {
        var trimmed = lines[i].trim();
        if (!trimmed || trimmed.indexOf('data: ') !== 0) continue;
        var data = trimmed.slice(6);
        if (data === '[DONE]') continue;
        try {
          var parsed = JSON.parse(data);
          var delta = parsed.choices && parsed.choices[0] && parsed.choices[0].delta;
          if (!delta) continue;
          // Pass ALL content types to onChunk - including reasoning_content
          var filtered = {};
          if (delta.reasoning_content) filtered.reasoning_content = delta.reasoning_content;
          if (delta.content) filtered.content = delta.content;
          if (delta.tool_calls) filtered.tool_calls = delta.tool_calls;
          if (filtered.reasoning_content || filtered.content || filtered.tool_calls) onChunk(filtered);
        } catch (_) {}
      }
    });
    res.on('end', resolve);
    res.on('error', reject);
  });
}

// Run agent turn (non-streaming, with tool loop)
async function runAgentTurn(modelConfig, projectId, conversation, useTools) {
  var localConv = conversation.slice();
  var turns = 0;
  var finalContent = '';

  while (turns < 8) {
    turns++;
    var result = await callModel(modelConfig, localConv, useTools ? TOOLS : undefined);
    var choice = result.choices && result.choices[0] && result.choices[0].message;
    if (!choice) break;

    finalContent = choice.content || '';
    var toolCalls = choice.tool_calls || [];

    localConv.push({
      role: 'assistant',
      content: finalContent || null,
      tool_calls: toolCalls.length > 0 ? toolCalls : undefined
    });

    if (toolCalls.length === 0 || !useTools) break;

    for (var i = 0; i < toolCalls.length; i++) {
      var tc = toolCalls[i];
      var args = safeJsonParse(tc.function && tc.function.arguments);
      var toolResult = executeTool(projectId, tc.function && tc.function.name, args);
      localConv.push({
        role: 'tool',
        tool_call_id: tc.id,
        content: JSON.stringify(toolResult)
      });
    }
  }

  return { content: finalContent, conversation: localConv };
}

// Run agent with tool event tracking
async function runAgentWithToolTracking(modelConfig, projectId, conversation, onEvent) {
  var turns = 0;
  var finalContent = '';

  while (turns < 8) {
    turns++;
    var result = await callModel(modelConfig, conversation, TOOLS);
    var choice = result.choices && result.choices[0] && result.choices[0].message;
    if (!choice) break;

    var content = choice.content || '';
    var toolCalls = choice.tool_calls || [];

    // Only update finalContent when there's actual content
    if (content) finalContent = content;

    conversation.push({
      role: 'assistant',
      content: content || null,
      tool_calls: toolCalls.length > 0 ? toolCalls : undefined
    });

    // If no tool calls, this is the final response
    if (toolCalls.length === 0) break;

    for (var i = 0; i < toolCalls.length; i++) {
      var tc = toolCalls[i];
      var fn = tc.function || {};
      var args = safeJsonParse(fn.arguments);
      onEvent({ type: 'tool_start', name: fn.name, args: args });
      var toolResult = executeTool(projectId, fn.name, args);
      onEvent({ type: 'tool_result', name: fn.name, result: toolResult });
      conversation.push({
        role: 'tool',
        tool_call_id: tc.id,
        content: JSON.stringify(toolResult)
      });
    }
  }

  // Fallback: if model never produced text, summarize what it did
  if (!finalContent) {
    var toolSummary = [];
    for (var ci = 0; ci < conversation.length; ci++) {
      var msg = conversation[ci];
      if (msg.role === 'assistant' && msg.tool_calls) {
        for (var ti = 0; ti < msg.tool_calls.length; ti++) {
          var tc = msg.tool_calls[ti];
          toolSummary.push('🔧 ' + (tc.function ? tc.function.name : '?'));
        }
      } else if (msg.role === 'tool') {
        try {
          var tr = JSON.parse(msg.content);
          if (tr.path) toolSummary[toolSummary.length - 1] += ' → ' + tr.path;
          if (tr.status) toolSummary[toolSummary.length - 1] += ' (' + tr.status + ')';
        } catch (_) {}
      }
    }
    finalContent = toolSummary.length > 0
      ? '已完成以下操作:\n' + toolSummary.join('\n')
      : '分析完成';
  }

  return { content: finalContent, conversation: conversation };
}

// SSE helper
function sseWrite(res, data) {
  if (!res.writableEnded) {
    try { res.write('data: ' + JSON.stringify(data) + '\n\n'); } catch (_) {}
  }
}

// Streaming chat with tool execution
async function runStreamingChat(modelConfig, projectId, conversation, res) {
  var turn = 0;
  while (turn < 10) {
    turn++;
    var assistantContent = '';
    var toolCalls = [];

    try {
      await callModelStream(modelConfig, conversation, TOOLS, function(delta) {
        if (delta.reasoning_content) {
          sseWrite(res, { type: 'thinking', text: delta.reasoning_content });
        }
        if (delta.content) {
          assistantContent += delta.content;
          sseWrite(res, { type: 'content', text: delta.content });
        }
        if (delta.tool_calls) {
          for (var i = 0; i < delta.tool_calls.length; i++) {
            var tc = delta.tool_calls[i];
            var idx = typeof tc.index === 'number' ? tc.index : 0;
            if (!toolCalls[idx]) toolCalls[idx] = { id: '', type: 'function', function: { name: '', arguments: '' } };
            if (tc.id) toolCalls[idx].id = tc.id;
            if (tc.function && tc.function.name) toolCalls[idx].function.name = tc.function.name;
            if (tc.function && tc.function.arguments) toolCalls[idx].function.arguments += tc.function.arguments;
          }
        }
      });
    } catch (e) {
      // Fallback to non-streaming
      try {
        var result = await callModel(modelConfig, conversation, TOOLS);
        var choice = result.choices && result.choices[0] && result.choices[0].message;
        if (!choice) { sseWrite(res, { type: 'error', error: e.message }); break; }
        assistantContent = choice.content || '';
        toolCalls = choice.tool_calls || [];
        if (assistantContent) sseWrite(res, { type: 'content', text: assistantContent });
      } catch (e2) {
        sseWrite(res, { type: 'error', error: 'API 调用失败: ' + e2.message });
        break;
      }
    }

    conversation.push({
      role: 'assistant',
      content: assistantContent || null,
      tool_calls: toolCalls.length > 0 ? toolCalls.map(function(tc, i) {
        return {
          id: tc.id || 'call_' + i,
          type: 'function',
          function: { name: tc.function.name, arguments: tc.function.arguments }
        };
      }) : undefined
    });

    if (toolCalls.length === 0) break;

    for (var i = 0; i < toolCalls.length; i++) {
      var tc = toolCalls[i];
      var args = safeJsonParse(tc.function && tc.function.arguments);
      var toolName = tc.function && tc.function.name;
      sseWrite(res, { type: 'tool_start', name: toolName, args: args });
      var toolResult = executeTool(projectId, toolName, args);
      sseWrite(res, { type: 'tool_result', name: toolName, result: toolResult });
      conversation.push({
        role: 'tool',
        tool_call_id: tc.id || 'call_' + Math.random(),
        content: JSON.stringify(toolResult)
      });
    }
  }

  // Trim conversation if too long (keep system prompt + last 40 messages)
  if (conversation.length > 50) {
    var systemMsg = conversation[0];
    var kept = conversation.slice(-40);
    conversation.length = 0;
    conversation.push(systemMsg);
    for (var t = 0; t < kept.length; t++) conversation.push(kept[t]);
  }
}

// --- API Routes ---

// Config (mask API keys for frontend display)
app.get('/api/config', function(req, res) {
  var safe = JSON.parse(JSON.stringify(config));
  safe.models.forEach(function(m) {
    var key = m.apiKey || '';
    if (key.length > 12) {
      m.apiKey = key.slice(0, 4) + '****' + key.slice(-4);
    }
    m._masked = true; // flag to know this is masked
  });
  res.json(safe);
});

app.post('/api/config', function(req, res) {
  var body = req.body;
  if (Array.isArray(body.models)) {
    body.models.forEach(function(m) {
      // If the key looks masked (contains ****), restore the real one
      if (m.apiKey && m.apiKey.indexOf('****') !== -1 && realApiKeys[m.id]) {
        m.apiKey = realApiKeys[m.id];
      } else if (m.apiKey) {
        // Real key provided, update our store
        realApiKeys[m.id] = m.apiKey;
      }
    });
    config.models = body.models;
  }
  if (body.mode) config.mode = body.mode;
  if (body.debateRounds != null) config.debateRounds = parseInt(body.debateRounds) || 2;
  res.json({ ok: true });
});

// Test API connection
app.post('/api/config/test', async function(req, res) {
  var b = req.body;
  if (!b.baseUrl || !b.model) return res.json({ ok: false, error: '缺少 baseUrl/model' });
  var apiKey = b.apiKey;
  // Support 'auto' key - resolve dynamically
  if (!apiKey || apiKey === 'auto') {
    if (b.modelId) {
      apiKey = getApiKey(b.modelId) || '';
    }
    if (!apiKey) {
      var found = config.models.find(function(m) { return m.baseUrl === b.baseUrl && m.model === b.model; });
      if (found) apiKey = found.apiKey;
    }
  }
  if (apiKey.indexOf('****') !== -1) {
    var found = config.models.find(function(m) { return m.baseUrl === b.baseUrl && m.model === b.model; });
    if (found) apiKey = found.apiKey;
  }
  if (!apiKey) return res.json({ ok: false, error: 'Key 未配置，请先刷新' });
  try {
    var result = await callModel(
      { baseUrl: b.baseUrl, apiKey: apiKey, model: b.model, id: b.modelId },
      [{ role: 'user', content: '只回复"连接成功"' }]
    );
    var content = result.choices && result.choices[0] && result.choices[0].message && result.choices[0].message.content;
    if (content) return res.json({ ok: true, response: content.slice(0, 100) });
    return res.json({ ok: true, response: '连接成功 (推理模式)' });
  } catch (err) {
    res.json({ ok: false, error: err.message });
  }
});

// Upload project
app.post('/api/upload', upload.single('file'), function(req, res) {
  try {
    if (!req.file) return res.status(400).json({ error: '没有上传文件' });
    var projectId = 'proj_' + Date.now();
    var projectRoot = path.join(UPLOAD_DIR, projectId);
    fs.mkdirSync(projectRoot, { recursive: true });

    var zip = new AdmZip(req.file.path);
    zip.extractAllTo(projectRoot, true);

    try { fs.unlinkSync(req.file.path); } catch (_) {}

    // Detect if single top-level folder
    var rootPath = projectRoot;
    try {
      var entries = fs.readdirSync(projectRoot, { withFileTypes: true });
      if (entries.length === 1 && entries[0].isDirectory()) {
        rootPath = path.join(projectRoot, entries[0].name);
      }
    } catch (_) {}

    var projectName = req.body.name || path.basename(req.file.originalname, '.zip');

    // Count files
    function countFilesDeep(dir) {
      var count = 0;
      try {
        var items = fs.readdirSync(dir, { withFileTypes: true });
        for (var i = 0; i < items.length; i++) {
          if (items[i].isDirectory()) {
            if (['node_modules', '.git', '__pycache__', '.next'].indexOf(items[i].name) === -1) {
              count += countFilesDeep(path.join(dir, items[i].name));
            }
          } else {
            count++;
          }
        }
      } catch (_) {}
      return count;
    }
    var fileCount = countFilesDeep(rootPath);

    projects.set(projectId, {
      id: projectId,
      name: projectName,
      rootPath: rootPath,
      fileCount: fileCount,
      conversations: {},
      createdAt: Date.now()
    });

    res.json({ projectId: projectId, name: projectName, fileCount: fileCount, message: '上传成功' });
    console.log('[项目已上传] ' + projectName + ' (ID: ' + projectId + ', ' + fileCount + ' 文件) — 跳过自动分析，用户对话时按需探索');
  } catch (err) {
    console.error('Upload error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Chat - Single mode (SSE streaming)
app.post('/api/chat', async function(req, res) {
  try {
    var body = req.body;
    if (!body.projectId || !body.message) return res.status(400).json({ error: '缺少 projectId 或 message' });

    var project = projects.get(body.projectId);
    if (!project) return res.status(404).json({ error: '项目不存在' });

    var model = config.models.find(function(m) { return m.id === body.modelId && m.enabled; }) ||
                config.models.find(function(m) { return m.enabled; });
    if (!model) return res.status(400).json({ error: '没有可用的模型' });

    if (!project.conversations[model.id]) {
      // First interaction: inject file tree into system prompt to save a tool call
      var sysPrompt = getSystemPrompt(model.name);
      if (!project._treeStr) {
        try { project._treeStr = buildFileTreeStr(project.rootPath).slice(0, 4000); } catch (_) {}
      }
      if (project._treeStr) sysPrompt += '\n\n## 当前项目文件结构\n```\n' + project._treeStr + '\n```';
      project.conversations[model.id] = [{ role: 'system', content: sysPrompt }];
    }

    var conv = project.conversations[model.id];
    conv.push({ role: 'user', content: body.message });

    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });

    await runStreamingChat(model, body.projectId, conv, res);
    res.end();
  } catch (err) {
    console.error('Chat error:', err);
    if (!res.headersSent) res.status(500).json({ error: err.message });
    else { sseWrite(res, { type: 'error', error: err.message }); res.end(); }
  }
});

// Chat - Multi/Debate mode (SSE streaming)
app.post('/api/chat-multi', async function(req, res) {
  try {
    var body = req.body;
    if (!body.projectId || !body.message) return res.status(400).json({ error: '缺少参数' });

    var project = projects.get(body.projectId);
    if (!project) return res.status(404).json({ error: '项目不存在' });

    var enabledModels = config.models.filter(function(m) { return m.enabled; });
    if (enabledModels.length < 2) return res.status(400).json({ error: '多AI模式至少需要2个启用的模型' });

    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });

    sseWrite(res, { type: 'phase', phase: 'discuss', message: '📢 多AI并行分析中...' });

    var proposals = [];
    for (var mi = 0; mi < enabledModels.length; mi++) {
      var model = enabledModels[mi];
      sseWrite(res, { type: 'thinking', agent: model.name, message: model.name + ' 分析中...' });

      if (!project.conversations[model.id]) {
        var sysPrompt = getSystemPrompt(model.name);
        if (!project._treeStr) {
          try { project._treeStr = buildFileTreeStr(project.rootPath).slice(0, 4000); } catch (_) {}
        }
        if (project._treeStr) sysPrompt += '\n\n## 当前项目文件结构\n```\n' + project._treeStr + '\n```';
        project.conversations[model.id] = [{ role: 'system', content: sysPrompt }];
      }

      var conv = project.conversations[model.id].slice();
      conv.push({ role: 'user', content: body.message });

      var result;
      try {
        result = await runAgentWithToolTracking(model, body.projectId, conv, function(evt) {
          sseWrite(res, { agent: model.name, type: evt.type, name: evt.name, args: evt.args, result: evt.result });
        });
      } catch (e) {
        console.error('[Multi-AI] ' + model.name + ' 失败:', e.message);
        sseWrite(res, { type: 'error', error: model.name + ' 失败: ' + e.message });
        result = { content: model.name + ' 调用失败: ' + e.message, conversation: conv };
      }

      proposals.push({ agent: model.name, modelId: model.id, content: result.content });
      project.conversations[model.id] = result.conversation;

      sseWrite(res, { type: 'proposal', agent: model.name, content: (result.content || '').slice(0, 500) });
    }

    // Filter out failed proposals
    proposals = proposals.filter(function(p) { return p.content && p.content.indexOf('调用失败') === -1; });
    if (proposals.length === 0) {
      sseWrite(res, { type: 'error', error: '所有 AI 模型调用失败，请检查 Key 配置' });
      res.end();
      return;
    }

    // Phase 2: Cross-review (debate mode)
    if (config.mode === 'debate' && config.debateRounds > 0) {
      sseWrite(res, { type: 'phase', phase: 'debate', message: '🔄 AI 互相评审中...' });

      for (var round = 0; round < config.debateRounds; round++) {
        for (var i = 0; i < enabledModels.length; i++) {
          var model = enabledModels[i];
          var others = proposals.filter(function(_, j) { return j !== i; });

          sseWrite(res, { type: 'thinking', agent: model.name, message: model.name + ' 评审中...' });

          var prompt = '其他AI的方案:\n\n' + others.map(function(p) { return '### ' + p.agent + ':\n' + p.content; }).join('\n\n') + '\n\n请给出你的改进方案。';
          var conv = project.conversations[model.id].slice();
          conv.push({ role: 'user', content: prompt });

          var result = await runAgentTurn(model, body.projectId, conv, false);
          proposals[i].content = result.content;
          project.conversations[model.id] = result.conversation;

          sseWrite(res, { type: 'review', agent: model.name, content: (result.content || '').slice(0, 300) });
        }
      }
    }

    // Phase 3: Synthesize
    sseWrite(res, { type: 'phase', phase: 'synthesize', message: '🧠 综合最优方案并执行...' });

    var arbiter = enabledModels[0];
    var finalPrompt = '各AI方案:\n\n' + proposals.map(function(p) { return '### ' + p.agent + ':\n' + p.content; }).join('\n\n') + '\n\n请综合最佳方案并直接执行修改。';
    var finalKey = arbiter.id + '_final';
    if (!project.conversations[finalKey]) {
      project.conversations[finalKey] = [{ role: 'system', content: getSystemPrompt(arbiter.name + '(仲裁)', '综合多AI方案，执行最优修改') }];
    }
    var finalConv = project.conversations[finalKey];
    finalConv.push({ role: 'user', content: finalPrompt });

    await runStreamingChat(arbiter, body.projectId, finalConv, res);

    sseWrite(res, { type: 'phase', phase: 'done', message: '✅ 多AI协作完成' });
    res.end();
  } catch (err) {
    console.error('Multi-chat error:', err);
    if (!res.headersSent) res.status(500).json({ error: err.message });
    else { sseWrite(res, { type: 'error', error: err.message }); res.end(); }
  }
});

// --- Project endpoints ---

app.get('/api/project/:id', function(req, res) {
  var project = projects.get(req.params.id);
  if (!project) return res.status(404).json({ error: '项目不存在' });

  function buildTree(dir, relPath) {
    relPath = relPath || '';
    var entries = [];
    try {
      var items = fs.readdirSync(dir, { withFileTypes: true });
      for (var i = 0; i < items.length; i++) {
        var item = items[i];
        if (['node_modules', '.git', '.DS_Store', '__pycache__', '.next'].indexOf(item.name) !== -1) continue;
        var itemRel = relPath ? relPath + '/' + item.name : item.name;
        if (item.isDirectory()) {
          entries.push({ name: item.name, type: 'directory', path: itemRel, children: buildTree(path.join(dir, item.name), itemRel) });
        } else {
          try {
            var stat = fs.statSync(path.join(dir, item.name));
            entries.push({ name: item.name, type: 'file', path: itemRel, size: stat.size });
          } catch (_) {}
        }
      }
    } catch (_) {}
    return entries.sort(function(a, b) {
      if (a.type !== b.type) return a.type === 'directory' ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
  }

  res.json({ id: project.id, name: project.name, tree: buildTree(project.rootPath) });
});

app.get('/api/project/:id/file', function(req, res) {
  try {
    var relPath = req.query.path;
    if (!relPath) return res.status(400).json({ error: '缺少 path 参数' });
    var fullPath = resolveProjectPath(req.params.id, relPath);
    if (!fs.existsSync(fullPath)) return res.status(404).json({ error: '文件不存在' });
    if (fs.statSync(fullPath).isDirectory()) return res.status(400).json({ error: '是目录不是文件' });
    res.json({ path: relPath, content: fs.readFileSync(fullPath, 'utf-8') });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/projects', function(req, res) {
  var list = [];
  projects.forEach(function(p, id) { list.push({ id: id, name: p.name, createdAt: p.createdAt }); });
  res.json({ projects: list });
});

app.delete('/api/project/:id', function(req, res) {
  var project = projects.get(req.params.id);
  if (!project) return res.status(404).json({ error: '项目不存在' });
  try { fs.rmSync(project.rootPath, { recursive: true, force: true }); } catch (_) {}
  projects.delete(req.params.id);
  res.json({ ok: true });
});

app.get('/api/project/:id/download', function(req, res) {
  var project = projects.get(req.params.id);
  if (!project) return res.status(404).json({ error: '项目不存在' });
  try {
    var zip = new AdmZip();
    zip.addLocalFolder(project.rootPath);
    res.set('Content-Type', 'application/zip');
    res.set('Content-Disposition', 'attachment; filename="' + encodeURIComponent(project.name) + '.zip"');
    res.send(zip.toBuffer());
  } catch (err) {
    res.status(500).json({ error: '打包失败: ' + err.message });
  }
});

app.get('/api/health', function(req, res) {
  res.json({ status: 'ok', mode: config.mode, models: config.models.filter(function(m) { return m.enabled; }).length, projects: projects.size });
});

// SPA fallback
app.get('*', function(req, res) {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, '0.0.0.0', function() {
  // Initialize key from best available source
  var envKey = process.env.MIMO_API_KEY || '';
  // Try /proc (always fresh, works for cloud-refreshed keys)
  if (!envKey) {
    try {
      var cp = require('child_process');
      var pids = cp.execSync("pgrep -f 'openclaw-gatewa'", { encoding: 'utf-8' }).trim().split('\n');
      for (var pi = 0; pi < pids.length; pi++) {
        var ep = '/proc/' + pids[pi].trim() + '/environ';
        if (fs.existsSync(ep)) {
          var envs = fs.readFileSync(ep, 'utf-8').split('\0');
          for (var ei = 0; ei < envs.length; ei++) {
            if (envs[ei].indexOf('MIMO_API_KEY=') === 0) {
              envKey = envs[ei].slice('MIMO_API_KEY='.length);
              break;
            }
          }
        }
        if (envKey) break;
      }
    } catch (_) {}
  }
  if (envKey) {
    var keys = {};
    try { keys = JSON.parse(fs.readFileSync(KEY_FILE, 'utf-8')); } catch (_) {}
    if (keys.mimo !== envKey) {
      keys.mimo = envKey;
      fs.writeFileSync(KEY_FILE, JSON.stringify(keys, null, 2), 'utf-8');
      console.log('[Key] 已初始化: ' + envKey.slice(0, 8) + '...' + envKey.slice(-4));
    }
  }

  console.log('\n🐾 MiMoClaw running on http://localhost:' + PORT);
  console.log('   Mode: ' + config.mode + ' | Models: ' + config.models.filter(function(m) { return m.enabled; }).length);
  console.log('   Key: ' + (envKey ? (envKey.slice(0, 8) + '...' + envKey.slice(-4)) : '⚠️ 未设置 MIMO_API_KEY'));
  console.log('   💡 运行 node key-refresher.js 保持 key 自动刷新');
  console.log('   Ready!\n');
});
