const express = require('express');
const multer = require('multer');
const AdmZip = require('adm-zip');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const https = require('https');

const app = express();
const PORT = process.env.PORT || 3000;

// --- Default Config ---
const DEFAULT_CONFIG = {
  models: [
    { id: 'mimo-1', name: 'MiMo-A', baseUrl: 'https://token-plan-cn.xiaomimimo.com/v1', apiKey: 'tp-cv10a8dd8e5wrxvq9rmc2hbvbyrup0c8cih15wo77vyvno3w', model: 'mimo-v2-pro', enabled: true },
    { id: 'mimo-2', name: 'MiMo-B', baseUrl: 'https://token-plan-cn.xiaomimimo.com/v1', apiKey: 'tp-cv10a8dd8e5wrxvq9rmc2hbvbyrup0c8cih15wo77vyvno3w', model: 'mimo-v2-pro', enabled: true },
    { id: 'mimo-3', name: 'MiMo-C', baseUrl: 'https://token-plan-cn.xiaomimimo.com/v1', apiKey: 'tp-cv10a8dd8e5wrxvq9rmc2hbvbyrup0c8cih15wo77vyvno3w', model: 'mimo-v2-pro', enabled: true },
    { id: 'mimo-4', name: 'MiMo-D', baseUrl: 'https://api.xiaomimimo.com/v1', apiKey: 'oc_chi6n2w2m866u60ylt0xo80o0wj6ijaj2exbvpoktyarjnzq', model: 'mimo-v2-pro', enabled: true },
  ],
  mode: 'single',
  debateRounds: 2,
};
let config = JSON.parse(JSON.stringify(DEFAULT_CONFIG));

// Keep real API keys in memory for restore after masked save
const realApiKeys = {};
DEFAULT_CONFIG.models.forEach(m => { realApiKeys[m.id] = m.apiKey; });

// --- Middleware ---
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// --- Upload ---
const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => cb(null, 'upload_' + Date.now() + '.zip')
});
const upload = multer({ storage, limits: { fileSize: 200 * 1024 * 1024 } });

// --- Projects ---
const projects = new Map();

// --- AI Tools ---
const TOOLS = [
  { type: 'function', function: { name: 'read_file', description: '读取文件内容', parameters: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] } } },
  { type: 'function', function: { name: 'write_file', description: '写入/修改/覆盖文件内容', parameters: { type: 'object', properties: { path: { type: 'string' }, content: { type: 'string' } }, required: ['path', 'content'] } } },
  { type: 'function', function: { name: 'list_files', description: '列出目录', parameters: { type: 'object', properties: { dir: { type: 'string', default: '.' } } } } },
  { type: 'function', function: { name: 'create_file', description: '创建新文件', parameters: { type: 'object', properties: { path: { type: 'string' }, content: { type: 'string' } }, required: ['path', 'content'] } } },
  { type: 'function', function: { name: 'delete_file', description: '删除文件', parameters: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] } } }
];

function getSystemPrompt(agentName, role) {
  var p = '你是 ' + agentName + '，AI 编程助手。\n';
  if (role) p += '角色: ' + role + '\n';
  p += '\n## 能力: 直接读写项目文件\n';
  p += '## 流程: 理解需求 → list_files 探索 → read_file 读取 → write_file 修改\n';
  p += '## 规则:\n- 修改前必须 read_file 看当前内容\n- write_file 会覆盖整个文件，请确保内容完整\n- 保持原有代码风格和缩进\n- 中文回复\n- 主动高效直接修改';
  return p;
}

// --- Safe path (cross-platform) ---
function normalizeSlashes(p) {
  return p.replace(/\\/g, '/');
}

function resolveProjectPath(projectId, relPath) {
  var project = projects.get(projectId);
  if (!project) throw new Error('项目不存在');
  var normalizedRel = normalizeSlashes(path.normalize(relPath)).replace(/^(\.\.\/?)+/, '');
  var normalizedRoot = normalizeSlashes(project.rootPath);
  var fullPath = normalizeSlashes(path.join(project.rootPath, normalizedRel));
  if (!fullPath.startsWith(normalizedRoot)) throw new Error('路径越权: ' + relPath);
  return fullPath;
}

// --- Tool execution ---
function executeTool(projectId, toolName, args) {
  try {
    switch (toolName) {
      case 'list_files': {
        var dir = args.dir || '.';
        var fullDir = resolveProjectPath(projectId, dir);
        if (!fs.existsSync(fullDir)) return { error: '目录不存在: ' + dir };
        if (!fs.statSync(fullDir).isDirectory()) return { error: dir + ' 不是目录' };
        var entries = fs.readdirSync(fullDir, { withFileTypes: true })
          .filter(function(e) { return ['node_modules', '.git', '.DS_Store', '__pycache__', '.next', 'dist', 'build', 'uploads'].indexOf(e.name) === -1; })
          .map(function(e) {
            return { name: e.name, type: e.isDirectory() ? 'directory' : 'file', path: dir === '.' ? e.name : dir + '/' + e.name };
          })
          .sort(function(a, b) {
            if (a.type !== b.type) return a.type === 'directory' ? -1 : 1;
            return a.name.localeCompare(b.name);
          });
        return { dir: dir, entries: entries };
      }
      case 'read_file': {
        var fullPath = resolveProjectPath(projectId, args.path);
        if (!fs.existsSync(fullPath)) return { error: '文件不存在: ' + args.path };
        var stat = fs.statSync(fullPath);
        if (stat.isDirectory()) return { error: args.path + ' 是目录，不是文件' };
        if (stat.size > 2 * 1024 * 1024) return { error: '文件过大 (' + (stat.size / 1024).toFixed(0) + 'KB)' };
        var ext = path.extname(args.path).toLowerCase();
        var binaryExts = ['.png', '.jpg', '.jpeg', '.gif', '.ico', '.woff', '.woff2', '.ttf', '.zip', '.exe', '.dll', '.so', '.dylib', '.mp4', '.mp3', '.wav', '.pdf', '.bin'];
        if (binaryExts.indexOf(ext) !== -1) return { error: '跳过二进制文件: ' + args.path };
        var content = fs.readFileSync(fullPath, 'utf-8');
        return { path: args.path, content: content, lines: content.split('\n').length, size: stat.size };
      }
      case 'write_file':
      case 'create_file': {
        var fullPath = resolveProjectPath(projectId, args.path);
        if (!args.content && args.content !== '') return { error: '缺少 content 参数' };
        var dir = path.dirname(fullPath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        var changeType = 'created';
        if (fs.existsSync(fullPath)) {
          changeType = 'modified';
          try {
            var old = fs.readFileSync(fullPath, 'utf-8');
            if (old === args.content) return { path: args.path, status: 'unchanged', message: '内容未变化' };
          } catch (_) {}
        }
        fs.writeFileSync(fullPath, args.content, 'utf-8');
        // Verify write
        try {
          var verify = fs.readFileSync(fullPath, 'utf-8');
          if (verify !== args.content) return { path: args.path, status: 'error', message: '写入验证失败' };
        } catch (_) {}
        return { path: args.path, status: changeType, message: changeType === 'created' ? '已创建' : '已修改' };
      }
      case 'delete_file': {
        var fullPath = resolveProjectPath(projectId, args.path);
        if (!fs.existsSync(fullPath)) return { error: '文件不存在: ' + args.path };
        if (fs.statSync(fullPath).isDirectory()) return { error: args.path + ' 是目录，不能用 delete_file 删除' };
        fs.unlinkSync(fullPath);
        return { path: args.path, status: 'deleted', message: '已删除' };
      }
      default:
        return { error: '未知工具: ' + toolName };
    }
  } catch (err) {
    return { error: err.message };
  }
}

// --- Safe JSON parse ---
function safeJsonParse(str) {
  if (!str) return {};
  try { return JSON.parse(str); } catch (_) { return {}; }
}

// --- MiMo API calls ---
function apiRequest(modelConfig, messages, tools, stream) {
  return new Promise(function(resolve, reject) {
    var body = JSON.stringify({
      model: modelConfig.model,
      messages: messages,
      tools: tools || undefined,
      tool_choice: tools ? 'auto' : undefined,
      stream: !!stream,
      temperature: 0.3,
      max_tokens: 4096
    });
    var urlStr = modelConfig.baseUrl;
    // Ensure URL ends with /chat/completions
    if (urlStr.indexOf('/chat/completions') === -1) {
      urlStr = urlStr.replace(/\/+$/, '') + '/chat/completions';
    }
    var url;
    try { url = new URL(urlStr); } catch (e) { return reject(new Error('无效的 Base URL: ' + urlStr)); }
    var req = https.request({
      hostname: url.hostname,
      port: url.port || 443,
      path: url.pathname + url.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + modelConfig.apiKey,
        'Content-Length': Buffer.byteLength(body)
      }
    }, function(res) {
      if (res.statusCode === 403) {
        var d = ''; res.on('data', function(c) { d += c; });
        res.on('end', function() { reject(new Error('API 403 权限错误: ' + d.slice(0, 200))); });
        return;
      }
      if (res.statusCode === 401) { reject(new Error('API Key 无效')); return; }
      if (res.statusCode >= 400) {
        var d = ''; res.on('data', function(c) { d += c; });
        res.on('end', function() { reject(new Error('API ' + res.statusCode + ': ' + d.slice(0, 200))); });
        return;
      }
      if (stream) {
        resolve(res);
      } else {
        var data = '';
        res.on('data', function(chunk) { data += chunk; });
        res.on('end', function() {
          try {
            var parsed = JSON.parse(data);
            if (parsed.error) return reject(new Error(parsed.error.message || JSON.stringify(parsed.error)));
            resolve(parsed);
          } catch (e) { reject(new Error('API 响应解析失败: ' + data.slice(0, 300))); }
        });
      }
    });
    req.on('error', reject);
    req.setTimeout(180000, function() { req.destroy(); reject(new Error('请求超时 (180s)')); });
    req.write(body);
    req.end();
  });
}

// Non-streaming call
function callModel(modelConfig, messages, tools) {
  return apiRequest(modelConfig, messages, tools, false).then(function(parsed) {
    if (parsed.choices) {
      for (var i = 0; i < parsed.choices.length; i++) {
        if (parsed.choices[i].message && parsed.choices[i].message.reasoning_content) {
          delete parsed.choices[i].message.reasoning_content;
        }
      }
    }
    return parsed;
  });
}

// Streaming call
async function callModelStream(modelConfig, messages, tools, onChunk) {
  var res = await apiRequest(modelConfig, messages, tools, true);
  return new Promise(function(resolve, reject) {
    var buffer = '';
    res.on('data', function(chunk) {
      buffer += chunk.toString();
      var lines = buffer.split('\n');
      buffer = lines.pop();
      for (var i = 0; i < lines.length; i++) {
        var trimmed = lines[i].trim();
        if (!trimmed || trimmed.indexOf('data: ') !== 0) continue;
        var data = trimmed.slice(6);
        if (data === '[DONE]') continue;
        try {
          var parsed = JSON.parse(data);
          var delta = parsed.choices && parsed.choices[0] && parsed.choices[0].delta;
          if (!delta) continue;
          if (delta.reasoning_content && !delta.content && !delta.tool_calls) continue;
          var filtered = {};
          if (delta.content) filtered.content = delta.content;
          if (delta.tool_calls) filtered.tool_calls = delta.tool_calls;
          if (filtered.content || filtered.tool_calls) onChunk(filtered);
        } catch (_) {}
      }
    });
    res.on('end', resolve);
    res.on('error', reject);
  });
}

// Run agent turn (non-streaming, with tool loop)
async function runAgentTurn(modelConfig, projectId, conversation, useTools) {
  var localConv = conversation.slice();
  var turns = 0;
  var finalContent = '';

  while (turns < 8) {
    turns++;
    var result = await callModel(modelConfig, localConv, useTools ? TOOLS : undefined);
    var choice = result.choices && result.choices[0] && result.choices[0].message;
    if (!choice) break;

    finalContent = choice.content || '';
    var toolCalls = choice.tool_calls || [];

    localConv.push({
      role: 'assistant',
      content: finalContent || null,
      tool_calls: toolCalls.length > 0 ? toolCalls : undefined
    });

    if (toolCalls.length === 0 || !useTools) break;

    for (var i = 0; i < toolCalls.length; i++) {
      var tc = toolCalls[i];
      var args = safeJsonParse(tc.function && tc.function.arguments);
      var toolResult = executeTool(projectId, tc.function && tc.function.name, args);
      localConv.push({
        role: 'tool',
        tool_call_id: tc.id,
        content: JSON.stringify(toolResult)
      });
    }
  }

  return { content: finalContent, conversation: localConv };
}

// Run agent with tool event tracking
async function runAgentWithToolTracking(modelConfig, projectId, conversation, onEvent) {
  var turns = 0;
  var finalContent = '';

  while (turns < 8) {
    turns++;
    var result = await callModel(modelConfig, conversation, TOOLS);
    var choice = result.choices && result.choices[0] && result.choices[0].message;
    if (!choice) break;

    finalContent = choice.content || '';
    var toolCalls = choice.tool_calls || [];

    conversation.push({
      role: 'assistant',
      content: finalContent || null,
      tool_calls: toolCalls.length > 0 ? toolCalls : undefined
    });

    if (toolCalls.length === 0) break;

    for (var i = 0; i < toolCalls.length; i++) {
      var tc = toolCalls[i];
      var fn = tc.function || {};
      var args = safeJsonParse(fn.arguments);
      onEvent({ type: 'tool_start', name: fn.name, args: args });
      var toolResult = executeTool(projectId, fn.name, args);
      onEvent({ type: 'tool_result', name: fn.name, result: toolResult });
      conversation.push({
        role: 'tool',
        tool_call_id: tc.id,
        content: JSON.stringify(toolResult)
      });
    }
  }

  return { content: finalContent, conversation: conversation };
}

// SSE helper
function sseWrite(res, data) {
  if (!res.writableEnded) {
    try { res.write('data: ' + JSON.stringify(data) + '\n\n'); } catch (_) {}
  }
}

// Streaming chat with tool execution
async function runStreamingChat(modelConfig, projectId, conversation, res) {
  var turn = 0;
  while (turn < 10) {
    turn++;
    var assistantContent = '';
    var toolCalls = [];

    try {
      await callModelStream(modelConfig, conversation, TOOLS, function(delta) {
        if (delta.content) {
          assistantContent += delta.content;
          sseWrite(res, { type: 'content', text: delta.content });
        }
        if (delta.tool_calls) {
          for (var i = 0; i < delta.tool_calls.length; i++) {
            var tc = delta.tool_calls[i];
            var idx = typeof tc.index === 'number' ? tc.index : 0;
            if (!toolCalls[idx]) toolCalls[idx] = { id: '', type: 'function', function: { name: '', arguments: '' } };
            if (tc.id) toolCalls[idx].id = tc.id;
            if (tc.function && tc.function.name) toolCalls[idx].function.name = tc.function.name;
            if (tc.function && tc.function.arguments) toolCalls[idx].function.arguments += tc.function.arguments;
          }
        }
      });
    } catch (e) {
      // Fallback to non-streaming
      try {
        var result = await callModel(modelConfig, conversation, TOOLS);
        var choice = result.choices && result.choices[0] && result.choices[0].message;
        if (!choice) { sseWrite(res, { type: 'error', error: e.message }); break; }
        assistantContent = choice.content || '';
        toolCalls = choice.tool_calls || [];
        if (assistantContent) sseWrite(res, { type: 'content', text: assistantContent });
      } catch (e2) {
        sseWrite(res, { type: 'error', error: 'API 调用失败: ' + e2.message });
        break;
      }
    }

    conversation.push({
      role: 'assistant',
      content: assistantContent || null,
      tool_calls: toolCalls.length > 0 ? toolCalls.map(function(tc, i) {
        return {
          id: tc.id || 'call_' + i,
          type: 'function',
          function: { name: tc.function.name, arguments: tc.function.arguments }
        };
      }) : undefined
    });

    if (toolCalls.length === 0) break;

    for (var i = 0; i < toolCalls.length; i++) {
      var tc = toolCalls[i];
      var args = safeJsonParse(tc.function && tc.function.arguments);
      var toolName = tc.function && tc.function.name;
      sseWrite(res, { type: 'tool_start', name: toolName, args: args });
      var toolResult = executeTool(projectId, toolName, args);
      sseWrite(res, { type: 'tool_result', name: toolName, result: toolResult });
      conversation.push({
        role: 'tool',
        tool_call_id: tc.id || 'call_' + Math.random(),
        content: JSON.stringify(toolResult)
      });
    }
  }

  // Trim conversation if too long (keep first message + last 40)
  if (conversation.length > 50) {
    var first = conversation[0];
    conversation.splice(1, conversation.length - 41);
  }
}

// --- API Routes ---

// Config (mask API keys for frontend display)
app.get('/api/config', function(req, res) {
  var safe = JSON.parse(JSON.stringify(config));
  safe.models.forEach(function(m) {
    var key = m.apiKey || '';
    if (key.length > 12) {
      m.apiKey = key.slice(0, 4) + '****' + key.slice(-4);
    }
    m._masked = true; // flag to know this is masked
  });
  res.json(safe);
});

app.post('/api/config', function(req, res) {
  var body = req.body;
  if (Array.isArray(body.models)) {
    body.models.forEach(function(m) {
      // If the key looks masked (contains ****), restore the real one
      if (m.apiKey && m.apiKey.indexOf('****') !== -1 && realApiKeys[m.id]) {
        m.apiKey = realApiKeys[m.id];
      } else if (m.apiKey) {
        // Real key provided, update our store
        realApiKeys[m.id] = m.apiKey;
      }
    });
    config.models = body.models;
  }
  if (body.mode) config.mode = body.mode;
  if (body.debateRounds != null) config.debateRounds = parseInt(body.debateRounds) || 2;
  res.json({ ok: true });
});

// Test API connection
app.post('/api/config/test', async function(req, res) {
  var b = req.body;
  if (!b.baseUrl || !b.apiKey || !b.model) return res.json({ ok: false, error: '缺少 baseUrl/apiKey/model' });
  // If key is masked, use real key
  var apiKey = b.apiKey;
  if (apiKey.indexOf('****') !== -1) {
    // Find real key from config
    var found = config.models.find(function(m) { return m.baseUrl === b.baseUrl && m.model === b.model; });
    if (found) apiKey = found.apiKey;
  }
  try {
    var result = await callModel(
      { baseUrl: b.baseUrl, apiKey: apiKey, model: b.model },
      [{ role: 'user', content: '只回复"连接成功"' }]
    );
    var content = result.choices && result.choices[0] && result.choices[0].message && result.choices[0].message.content;
    if (content) return res.json({ ok: true, response: content.slice(0, 100) });
    return res.json({ ok: true, response: '连接成功 (推理模式)' });
  } catch (err) {
    res.json({ ok: false, error: err.message });
  }
});

// Upload project
app.post('/api/upload', upload.single('file'), function(req, res) {
  try {
    if (!req.file) return res.status(400).json({ error: '没有上传文件' });
    var projectId = 'proj_' + Date.now();
    var projectRoot = path.join(UPLOAD_DIR, projectId);
    fs.mkdirSync(projectRoot, { recursive: true });

    var zip = new AdmZip(req.file.path);
    zip.extractAllTo(projectRoot, true);

    try { fs.unlinkSync(req.file.path); } catch (_) {}

    // Detect if single top-level folder
    var rootPath = projectRoot;
    try {
      var entries = fs.readdirSync(projectRoot, { withFileTypes: true });
      if (entries.length === 1 && entries[0].isDirectory()) {
        rootPath = path.join(projectRoot, entries[0].name);
      }
    } catch (_) {}

    var projectName = req.body.name || path.basename(req.file.originalname, '.zip');

    projects.set(projectId, {
      id: projectId,
      name: projectName,
      rootPath: rootPath,
      conversations: {},
      createdAt: Date.now()
    });

    res.json({ projectId: projectId, name: projectName, message: '上传成功' });

    // Auto analysis (background)
    var firstModel = config.models.find(function(m) { return m.enabled; });
    if (firstModel) {
      var conv = [
        { role: 'system', content: getSystemPrompt(firstModel.name) },
        { role: 'user', content: '已上传项目 "' + projectName + '"。请先 list_files 了解结构，然后简要介绍这个项目。' }
      ];
      runAgentTurn(firstModel, projectId, conv, true)
        .then(function(result) {
          var proj = projects.get(projectId);
          if (proj) proj.conversations[firstModel.id] = result.conversation;
          console.log('[分析完成] ' + projectName);
        })
        .catch(function(e) { console.error('[分析失败] ' + projectName + ':', e.message); });
    }
  } catch (err) {
    console.error('Upload error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Chat - Single mode (SSE streaming)
app.post('/api/chat', async function(req, res) {
  try {
    var body = req.body;
    if (!body.projectId || !body.message) return res.status(400).json({ error: '缺少 projectId 或 message' });

    var project = projects.get(body.projectId);
    if (!project) return res.status(404).json({ error: '项目不存在' });

    var model = config.models.find(function(m) { return m.id === body.modelId && m.enabled; }) ||
                config.models.find(function(m) { return m.enabled; });
    if (!model) return res.status(400).json({ error: '没有可用的模型' });

    if (!project.conversations[model.id]) {
      project.conversations[model.id] = [{ role: 'system', content: getSystemPrompt(model.name) }];
    }

    var conv = project.conversations[model.id];
    conv.push({ role: 'user', content: body.message });

    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });

    await runStreamingChat(model, body.projectId, conv, res);
    res.end();
  } catch (err) {
    console.error('Chat error:', err);
    if (!res.headersSent) res.status(500).json({ error: err.message });
    else { sseWrite(res, { type: 'error', error: err.message }); res.end(); }
  }
});

// Chat - Multi/Debate mode (SSE streaming)
app.post('/api/chat-multi', async function(req, res) {
  try {
    var body = req.body;
    if (!body.projectId || !body.message) return res.status(400).json({ error: '缺少参数' });

    var project = projects.get(body.projectId);
    if (!project) return res.status(404).json({ error: '项目不存在' });

    var enabledModels = config.models.filter(function(m) { return m.enabled; });
    if (enabledModels.length < 2) return res.status(400).json({ error: '多AI模式至少需要2个启用的模型' });

    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });

    sseWrite(res, { type: 'phase', phase: 'discuss', message: '📢 多AI并行分析中...' });

    var proposals = [];
    for (var mi = 0; mi < enabledModels.length; mi++) {
      var model = enabledModels[mi];
      sseWrite(res, { type: 'thinking', agent: model.name, message: model.name + ' 分析中...' });

      if (!project.conversations[model.id]) {
        project.conversations[model.id] = [{ role: 'system', content: getSystemPrompt(model.name) }];
      }

      var conv = project.conversations[model.id].slice();
      conv.push({ role: 'user', content: body.message });

      var result = await runAgentWithToolTracking(model, body.projectId, conv, function(evt) {
        sseWrite(res, { agent: model.name, type: evt.type, name: evt.name, args: evt.args, result: evt.result });
      });

      proposals.push({ agent: model.name, modelId: model.id, content: result.content });
      project.conversations[model.id] = result.conversation;

      sseWrite(res, { type: 'proposal', agent: model.name, content: (result.content || '').slice(0, 500) });
    }

    // Phase 2: Cross-review (debate mode)
    if (config.mode === 'debate' && config.debateRounds > 0) {
      sseWrite(res, { type: 'phase', phase: 'debate', message: '🔄 AI 互相评审中...' });

      for (var round = 0; round < config.debateRounds; round++) {
        for (var i = 0; i < enabledModels.length; i++) {
          var model = enabledModels[i];
          var others = proposals.filter(function(_, j) { return j !== i; });

          sseWrite(res, { type: 'thinking', agent: model.name, message: model.name + ' 评审中...' });

          var prompt = '其他AI的方案:\n\n' + others.map(function(p) { return '### ' + p.agent + ':\n' + p.content; }).join('\n\n') + '\n\n请给出你的改进方案。';
          var conv = project.conversations[model.id].slice();
          conv.push({ role: 'user', content: prompt });

          var result = await runAgentTurn(model, body.projectId, conv, false);
          proposals[i].content = result.content;
          project.conversations[model.id] = result.conversation;

          sseWrite(res, { type: 'review', agent: model.name, content: (result.content || '').slice(0, 300) });
        }
      }
    }

    // Phase 3: Synthesize
    sseWrite(res, { type: 'phase', phase: 'synthesize', message: '🧠 综合最优方案并执行...' });

    var arbiter = enabledModels[0];
    var finalPrompt = '各AI方案:\n\n' + proposals.map(function(p) { return '### ' + p.agent + ':\n' + p.content; }).join('\n\n') + '\n\n请综合最佳方案并直接执行修改。';
    var finalKey = arbiter.id + '_final';
    if (!project.conversations[finalKey]) {
      project.conversations[finalKey] = [{ role: 'system', content: getSystemPrompt(arbiter.name + '(仲裁)', '综合多AI方案，执行最优修改') }];
    }
    var finalConv = project.conversations[finalKey];
    finalConv.push({ role: 'user', content: finalPrompt });

    await runStreamingChat(arbiter, body.projectId, finalConv, res);

    sseWrite(res, { type: 'phase', phase: 'done', message: '✅ 多AI协作完成' });
    res.end();
  } catch (err) {
    console.error('Multi-chat error:', err);
    if (!res.headersSent) res.status(500).json({ error: err.message });
    else { sseWrite(res, { type: 'error', error: err.message }); res.end(); }
  }
});

// --- Project endpoints ---

app.get('/api/project/:id', function(req, res) {
  var project = projects.get(req.params.id);
  if (!project) return res.status(404).json({ error: '项目不存在' });

  function buildTree(dir, relPath) {
    relPath = relPath || '';
    var entries = [];
    try {
      var items = fs.readdirSync(dir, { withFileTypes: true });
      for (var i = 0; i < items.length; i++) {
        var item = items[i];
        if (['node_modules', '.git', '.DS_Store', '__pycache__', '.next'].indexOf(item.name) !== -1) continue;
        var itemRel = relPath ? relPath + '/' + item.name : item.name;
        if (item.isDirectory()) {
          entries.push({ name: item.name, type: 'directory', path: itemRel, children: buildTree(path.join(dir, item.name), itemRel) });
        } else {
          try {
            var stat = fs.statSync(path.join(dir, item.name));
            entries.push({ name: item.name, type: 'file', path: itemRel, size: stat.size });
          } catch (_) {}
        }
      }
    } catch (_) {}
    return entries.sort(function(a, b) {
      if (a.type !== b.type) return a.type === 'directory' ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
  }

  res.json({ id: project.id, name: project.name, tree: buildTree(project.rootPath) });
});

app.get('/api/project/:id/file', function(req, res) {
  try {
    var relPath = req.query.path;
    if (!relPath) return res.status(400).json({ error: '缺少 path 参数' });
    var fullPath = resolveProjectPath(req.params.id, relPath);
    if (!fs.existsSync(fullPath)) return res.status(404).json({ error: '文件不存在' });
    if (fs.statSync(fullPath).isDirectory()) return res.status(400).json({ error: '是目录不是文件' });
    res.json({ path: relPath, content: fs.readFileSync(fullPath, 'utf-8') });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/projects', function(req, res) {
  var list = [];
  projects.forEach(function(p, id) { list.push({ id: id, name: p.name, createdAt: p.createdAt }); });
  res.json({ projects: list });
});

app.delete('/api/project/:id', function(req, res) {
  var project = projects.get(req.params.id);
  if (!project) return res.status(404).json({ error: '项目不存在' });
  try { fs.rmSync(project.rootPath, { recursive: true, force: true }); } catch (_) {}
  projects.delete(req.params.id);
  res.json({ ok: true });
});

app.get('/api/project/:id/download', function(req, res) {
  var project = projects.get(req.params.id);
  if (!project) return res.status(404).json({ error: '项目不存在' });
  try {
    var zip = new AdmZip();
    zip.addLocalFolder(project.rootPath);
    res.set('Content-Type', 'application/zip');
    res.set('Content-Disposition', 'attachment; filename="' + encodeURIComponent(project.name) + '.zip"');
    res.send(zip.toBuffer());
  } catch (err) {
    res.status(500).json({ error: '打包失败: ' + err.message });
  }
});

app.get('/api/health', function(req, res) {
  res.json({ status: 'ok', mode: config.mode, models: config.models.filter(function(m) { return m.enabled; }).length, projects: projects.size });
});

// SPA fallback
app.get('*', function(req, res) {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, '0.0.0.0', function() {
  console.log('\n🐾 MiMoClaw running on http://localhost:' + PORT);
  console.log('   Mode: ' + config.mode + ' | Models: ' + config.models.filter(function(m) { return m.enabled; }).length);
  console.log('   Ready!\n');
});
